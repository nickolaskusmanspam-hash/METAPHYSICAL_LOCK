SANCTUARY MANIFEST v1.0
Operator: Chef_Yaboiardee
Version: Minecraft Java Edition 1.20.1

INSTRUCTIONS:
1. Create a new folder for your server (e.g., SanctuaryServer)
2. Place the Minecraft 1.20.1 server JAR inside it
3. Copy the contents of this manifest into the server directory
4. Run start.bat or start.sh to generate files
5. Accept EULA
6. Replace 'world' folder with your Sanctuary world (when ready)
7. Use included setblock_commands.txt in command blocks or admin terminal
8. Begin with /tp @p 0 64 0 — Operator's Echo
