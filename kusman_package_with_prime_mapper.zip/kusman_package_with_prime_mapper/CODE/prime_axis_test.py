\
import argparse, yaml, math, hashlib, re
from math import pi, sqrt, log1p
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from prime_path_mapper import (
    parse_shush_corpora, estimate_gate_from_corpus, embed_seed_to_torus,
    evolve, primes_upto, min_distance_to_path
)

# Deterministic Miller-Rabin for 64-bit integers
def is_prime64(n: int) -> bool:
    if n < 2: return False
    small_primes = [2,3,5,7,11,13,17,19,23,29,31,37]
    for p in small_primes:
        if n % p == 0:
            return n == p
    # write n-1 = d*2^s
    d = n-1; s = 0
    while d % 2 == 0:
        s += 1; d //= 2
    # bases sufficient for 64-bit correctness
    for a in [2, 3, 5, 7, 11, 13, 17]:
        if a >= n: continue
        x = pow(a, d, n)
        if x == 1 or x == n-1: continue
        skip = False
        for _ in range(s-1):
            x = (x*x) % n
            if x == n-1:
                skip = True
                break
        if skip: continue
        return False
    return True

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True, help="Path to SHUSH-style CSV")
    ap.add_argument("--config", required=True, help="YAML config")
    ap.add_argument("--out", required=True, help="Output directory")
    args = ap.parse_args()

    cfg = yaml.safe_load(Path(args.config).read_text())
    seed = cfg.get("seed", "demo-key-seed")
    beta = float(cfg.get("beta", 0.25))
    T = int(cfg.get("T", 2048))
    Nmin = int(cfg.get("Nmin", 1000))
    Nmax = int(cfg.get("Nmax", 10000))
    eps = float(cfg.get("epsilon", 0.10))
    B = int(cfg.get("B", 8))
    rho_r = float(cfg.get("rho_r", 0.5))
    label_hint = cfg.get("label_hint")
    topM = int(cfg.get("topM", 200))

    corpora = parse_shush_corpora(args.input)
    if label_hint and label_hint in corpora:
        rows = corpora[label_hint]; used_label = label_hint
    else:
        used_label = next(iter(corpora.keys())); rows = corpora[used_label]

    rho_theta, g_bins = estimate_gate_from_corpus(rows, eps=eps, B=B)
    phi0, psi0 = embed_seed_to_torus(seed)
    phi_path, psi_path = evolve(phi0, psi0, rho_theta, rho_r, beta*g_bins, steps=T)

    n = np.arange(Nmin, Nmax+1)
    phi_n = (n * rho_theta) % 1.0
    psi_n = (n * rho_r) % 1.0

    # compute distance for all n (not just primes) to allow ranking & precision calc
    d_all = min_distance_to_path(phi_n, psi_n, phi_path, psi_path, chunk=1024)
    df = pd.DataFrame({"n": n, "phi": phi_n, "psi": psi_n, "dist": d_all})
    df = df.sort_values("dist").reset_index(drop=True)

    # pick topM candidates and check primality
    cand = df.head(topM).copy()
    cand["is_prime"] = cand["n"].apply(lambda x: is_prime64(int(x)))
    precision_at_M = float(cand["is_prime"].mean()) if len(cand)>0 else float("nan")

    # also compute baseline prime rate in the whole window
    is_prime_window = [is_prime64(int(x)) for x in n]
    baseline_rate = float(np.mean(is_prime_window))

    outdir = Path(args.out); outdir.mkdir(parents=True, exist_ok=True)
    cand.to_csv(outdir / "test_candidates.csv", index=False)

    # quick plot: dist vs n with prime markers
    import matplotlib.pyplot as plt
    plt.figure(figsize=(8,4))
    plt.scatter(df["n"], df["dist"], s=6, alpha=0.5, label="all n")
    maskp = np.array(is_prime_window, dtype=bool)
    plt.scatter(n[maskp], d_all[maskp], s=8, alpha=0.8, label="primes")
    plt.title(f"Distance-to-trajectory vs n  (label={used_label})")
    plt.xlabel("n"); plt.ylabel("torus distance to path")
    plt.legend(); plt.tight_layout()
    plt.savefig(outdir / "test_dist_vs_n.png", dpi=180, bbox_inches="tight"); plt.close()

    # write summary
    summary = {
        "label": used_label,
        "window": [int(Nmin), int(Nmax)],
        "topM": int(topM),
        "precision_at_M": precision_at_M,
        "baseline_prime_rate": baseline_rate,
        "rho_theta": float(rho_theta),
        "rho_r": float(rho_r),
        "beta": float(beta),
        "B": int(B),
        "epsilon": float(eps)
    }
    (outdir / "test_summary.json").write_text(json.dumps(summary, indent=2))

if __name__ == "__main__":
    main()
