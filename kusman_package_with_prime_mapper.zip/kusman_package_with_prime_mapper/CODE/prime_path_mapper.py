\
import argparse, re, hashlib, math, yaml
from math import pi, sqrt
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

def dwrap(a, b):
    x = abs(a - b) % 1.0
    return min(x, 1.0 - x)

def torus_dist_pair(p, q):
    return sqrt(dwrap(p[0], q[0])**2 + dwrap(p[1], q[1])**2)

def embed_seed_to_torus(seed: str, salt_phi=b"phi", salt_psi=b"psi"):
    bs = seed.encode()
    h1 = hashlib.blake2s(salt=salt_phi, digest_size=16); h1.update(bs); phi = int.from_bytes(h1.digest(), "big") / 2**128
    h2 = hashlib.blake2s(salt=salt_psi, digest_size=16); h2.update(bs); psi = int.from_bytes(h2.digest(), "big") / 2**128
    return (phi % 1.0, psi % 1.0)

def parse_shush_corpora(path):
    df = pd.read_csv(path, dtype=str).fillna("")
    row_strs = [" | ".join(map(str, r)) for r in df.values.tolist()]
    header_pat = re.compile(r"Round\s*.*Derived\s*CA\s*Rules.*Operator\s*Angle.*Operator\s*Axis", re.I)
    headers = [i for i, s in enumerate(row_strs) if header_pat.search(s)]
    entry_pat = re.compile(r"\|\s*(\d{1,3})\s*\|\s*\[\[([^\]]+)\]\]\s*\|\s*([0-9.]+)\s*\|\s*\[([0-9.,\-\s]+)\]")
    def get_label(idx):
        for k in range(1, 12):
            j = idx - k
            if j < 0: break
            s = row_strs[j]
            m2 = re.search(r"Public\s*Key:([0-9A-Fa-f]+)", s)
            if m2: return "PK_" + m2.group(1)[:12]
            m = re.search(r"Bitcoin\s*Puzzle\s*#\s*(\d+)", s, re.I)
            if m: return f"Puzzle #{m.group(1)}"
        return f"Corpus_{idx}"
    corpora = {}
    for h in headers:
        label = get_label(h)
        rows = []
        i = h + 1
        while i < len(row_strs):
            s = row_strs[i]
            if header_pat.search(s): break
            m = entry_pat.search(s)
            if m:
                idx = int(m.group(1)); angle = float(m.group(3))
                rows.append((idx, angle))
            i += 1
        if rows:
            rows.sort(key=lambda t: t[0])
            corpora[label] = rows
    return corpora

def estimate_gate_from_corpus(rows, eps=0.10, B=8):
    import numpy as np
    idx = np.array([r[0] for r in rows], dtype=int)
    ang = np.array([r[1] for r in rows], dtype=float)
    near2pi = (np.abs(ang - 2*np.pi) <= eps).astype(int)
    phase = idx % B
    p_global = near2pi.mean()
    pB = np.array([near2pi[phase==k].mean() if (phase==k).any() else p_global for k in range(B)])
    pB = np.nan_to_num(pB, nan=p_global)
    g = pB - pB.mean()
    rho_theta = float(np.round(ang/(2*np.pi)).mean())
    return rho_theta, g

def evolve(phi0, psi0, rho_theta, rho_r, g_bins, steps):
    import numpy as np
    B = len(g_bins)
    phi = np.zeros(steps+1); psi = np.zeros(steps+1)
    phi[0], psi[0] = phi0, psi0
    for t in range(steps):
        phbin = int((psi[t]*B) % B)
        gate = g_bins[phbin]
        phi[t+1] = (phi[t] + rho_theta + gate) % 1.0
        psi[t+1] = (psi[t] + rho_r) % 1.0
    return phi, psi

def primes_upto(N):
    sieve = np.ones(N+1, dtype=bool); sieve[:2]=False
    for p in range(2, int(N**0.5)+1):
        if sieve[p]:
            sieve[p*p:N+1:p] = False
    return np.flatnonzero(sieve)

def min_distance_to_path(phi_points, psi_points, path_phi, path_psi, chunk=2048):
    # Compute torus min distance for each (phi_points[i], psi_points[i]) to the polyline path (discrete points)
    import numpy as np
    M = len(path_phi)
    out = np.empty(len(phi_points), dtype=float)
    for s in range(0, len(phi_points), chunk):
        e = min(len(phi_points), s+chunk)
        ph = phi_points[s:e][:, None]  # (K,1)
        ps = psi_points[s:e][:, None]  # (K,1)
        dx = np.abs(ph - path_phi[None, :]); dx = np.minimum(dx, 1.0 - dx)
        dy = np.abs(ps - path_psi[None, :]); dy = np.minimum(dy, 1.0 - dy)
        dist = np.sqrt(dx*dx + dy*dy)      # (K,M)
        out[s:e] = dist.min(axis=1)
    return out

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True, help="Path to SHUSH-style CSV")
    ap.add_argument("--config", required=True, help="YAML config")
    ap.add_argument("--out", required=True, help="Output directory")
    args = ap.parse_args()

    cfg = yaml.safe_load(Path(args.config).read_text())
    seed = cfg.get("seed", "demo-key-seed")
    beta = float(cfg.get("beta", 0.25))
    T = int(cfg.get("T", 4096))
    Nmax = int(cfg.get("Nmax", 20000))
    eps = float(cfg.get("epsilon", 0.10))
    B = int(cfg.get("B", 8))
    rho_r = float(cfg.get("rho_r", 0.5))
    label_hint = cfg.get("label_hint")

    corpora = parse_shush_corpora(args.input)
    # choose a corpus to learn gate
    if label_hint and label_hint in corpora:
        rows = corpora[label_hint]
        used_label = label_hint
    else:
        used_label = next(iter(corpora.keys()))
        rows = corpora[used_label]

    rho_theta, g_bins = estimate_gate_from_corpus(rows, eps=eps, B=B)
    phi0, psi0 = embed_seed_to_torus(seed)
    phi_path, psi_path = evolve(phi0, psi0, rho_theta, rho_r, beta*g_bins, steps=T)

    # embed integers and rank primes
    n = np.arange(Nmax+1)
    phi_n = (n * rho_theta) % 1.0
    psi_n = (n * rho_r) % 1.0

    P = primes_upto(Nmax)
    dP = min_distance_to_path(phi_n[P], psi_n[P], phi_path, psi_path)
    inpath = pd.DataFrame({"prime": P, "phi": phi_n[P], "psi": psi_n[P], "min_distance_to_path": dP})
    inpath = inpath.sort_values("min_distance_to_path").reset_index(drop=True)

    outdir = Path(args.out); outdir.mkdir(parents=True, exist_ok=True)
    inpath.to_csv(outdir / "top_primes.csv", index=False)

    # small plot
    import matplotlib.pyplot as plt
    k = min(200, len(inpath))
    plt.figure(figsize=(7,6))
    plt.plot(phi_path, psi_path, linewidth=0.6, alpha=0.85, label="trajectory Γ")
    sel = inpath.head(k)
    plt.scatter(sel["phi"], sel["psi"], s=12, marker="o", alpha=0.9, label=f"top-{k} primes in-path")
    plt.title(f"Primes near trajectory — label={used_label}")
    plt.xlabel("φ"); plt.ylabel("ψ"); plt.legend()
    plt.gca().set_aspect("equal", adjustable="box"); plt.grid(True, linewidth=0.3)
    plt.tight_layout(); plt.savefig(outdir / "inpath_primes_plot.png", dpi=200, bbox_inches="tight"); plt.close()

    meta = {
        "used_label": used_label,
        "rho_theta": float(rho_theta),
        "rho_r": float(rho_r),
        "beta": float(beta),
        "B": int(B),
        "epsilon": float(eps),
        "seed_hint": seed[:8]+"…",
        "Nmax": int(Nmax),
        "T": int(T),
    }
    (outdir / "prime_path_meta.json").write_text(yaml.safe_dump(meta))

if __name__ == "__main__":
    main()
