KUSMAN Package — Torus Engine, Prime-Path Mapper, and Small Test (No formulas here)
----------------------------------------------------------------------------------
This bundle adds:
• CODE/prime_path_mapper.py — ranks integers (esp. primes) by proximity to a gate-driven torus trajectory from a safe seed.
• CODE/prime_axis_test.py — a small, configurable test to check if the prime ranking aligns with true primality.
• CONFIG/prime_path_config.yaml — knobs for the mapper.
• CONFIG/test_prime_axis.yaml — a small test config; safe defaults.

Usage (quick)
-------------
1) Install Python 3.10+ and the packages in CODE/requirements.txt.
2) Update CONFIG/*.yaml as needed.
3) Run the mapper, for example:
   python CODE/prime_path_mapper.py --input "/path/to/SHUSH - Sheet1.csv" --config CONFIG/prime_path_config.yaml --out OUTPUTS
4) Run the small test:
   python CODE/prime_axis_test.py --input "/path/to/SHUSH - Sheet1.csv" --config CONFIG/test_prime_axis.yaml --out OUTPUTS

Notes
-----
• This is a research/diagnostics tool, not a cryptographic key-recovery method.
• The seed is a string hashed to (φ,ψ); do not place private keys in configs.
• The “precision” checked by the test means: candidates flagged by the torus engine
  are actually prime under a standard primality test (deterministic for 64-bit ranges).
