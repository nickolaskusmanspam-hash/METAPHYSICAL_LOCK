KUSMAN Package — Torus Engine & Diagnostics (No formulas in this overview)

This overview intentionally contains no formulas. See FORMULAE/*.tex for the full math.
