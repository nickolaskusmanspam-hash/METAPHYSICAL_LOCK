Expected table headers: Round | [[Derived CA Rules]] | Operator Angle (rad) | [Operator Axis]
