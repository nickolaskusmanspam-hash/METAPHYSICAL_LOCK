
# 06 — P vs NP Note: Where the Proof Would Need a New Idea

The note asserts **P = NP** by assuming that, for every input reduced to 3‑SAT, the number \( \mathcal S(n) \) of
distinct clause‑sets visited under a “symbolic merge‑recursion” solver is **polynomially bounded**.

- This polynomial bound is exactly the hard part; without a proof **uniform over all instances**, the conclusion does
  not follow.
- The merge rule (identifying clause‑sets with identical sets of completions) is sound *as a definition*, but proving
  that the induced search graph has only \(n^{O(1)}\) nodes for all inputs would be a breakthrough.

**Status.** At present **conditional** on the polynomial bound; unconditional proof is not provided.
