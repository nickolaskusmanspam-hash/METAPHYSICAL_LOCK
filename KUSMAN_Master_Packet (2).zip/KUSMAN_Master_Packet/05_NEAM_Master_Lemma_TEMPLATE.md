
# 05 — NEAM Master Lemma Template (with explicit hypotheses)

The “Non‑Euclidean Automata‑based Morphodynamics” document presents a powerful **template**. We restate it cleanly
with hypotheses (H1)–(H5) and conclusions (C1)–(C6).

- Treat this as a *conditional theorem schema*. Under small‑step curvature control, a negative cycle‑mean certificate,
  spectral nonresonance, and an orientation signature, one obtains a toroidal/Klein semi‑conjugacy with exponential
  contraction transverse to the base and algorithmic corollaries on structured families.

**Status.** Correct as a conditional schema; turning it into a theorem for any concrete system (e.g., Collatz) requires
exhibiting (H1)–(H5) for that system.
