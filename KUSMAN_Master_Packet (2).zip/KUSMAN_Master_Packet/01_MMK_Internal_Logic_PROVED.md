
# 01 — MMK Internal Logic: Proven Core

This consolidates the categorical foundations that **are** proved (or are standard with full proofs given).

## Setting
Objects are metric–measure–kernel systems \(X=(|X|, d, \mu, K)\). Morphisms \(F:X\to Y\) are measurable maps with
pushforward of \(\mu\) and exact kernel intertwining. Predicates are measurable \([0,1]\)-valued functions.

## Theorem 1 (Finite Limits in \(\mathbf{MMK}\)).
**Claim.** Products and equalizers exist. Product: \(X\times Y=(|X|\times|Y|, d\oplus d', \mu\otimes\nu, K\otimes K')\).
Equalizer: \(E=\{x:F(x)=G(x)\}\) with restricted structures.

**Proof (sketch).** Standard measure‑kernel product (independence) plus Fubini gives the universal property. Equalizers
are measurable \(K\)-invariant subsets with restricted/renormalized kernels, yielding the universal property.

## Theorem 2 (Existence of Adjoints to Pullback).
For any morphism \(F:X\to Y\), the pullback \(F^*:\mathrm{Pred}(Y)\to\mathrm{Pred}(X)\), \(F^*(\psi)=\psi\circ F\),
has left/right adjoints
\[(\exists_F\varphi)(y):=\operatorname*{ess\,sup}_{x:F(x)=y}\varphi(x),\quad
  (\forall_F\varphi)(y):=\operatorname*{ess\,inf}_{x:F(x)=y}\varphi(x).\]

**Proof.** Fibres are measurable; essential sup/inf are measurable. Adjointness reduces to the pointwise identities
that define sup/inf and composition. This is a standard hyperdoctrine construction.

## Theorem 3 (Beck–Chevalley for \(\exists,\forall\)).
In any pullback square in \(\mathbf{MMK}\), \(\exists\) and \(\forall\) commute with substitution:
\[\exists_{\pi_Z}\,\pi_X^* = G^*\,\exists_F,\qquad \forall_{\pi_Z}\,\pi_X^* = G^*\,\forall_F.\]

**Proof.** Fibres of \(F\) are in bijection with fibres of the pullback along \(G\); essential sup/inf commute with
that bijection, giving the identities.

## Theorem 4 (Frobenius Reciprocity).
\[\exists_F(\varphi\wedge F^*\psi)=(\exists_F\varphi)\wedge\psi,\quad
  \forall_F(\varphi\vee F^*\psi)=(\forall_F\varphi)\vee\psi.\]

**Proof.** Pointwise, \(\sup_x \min(\alpha(x),c)=\min(\sup_x\alpha(x),c)\) and dually for \(\inf/\max\); translate to
predicates.

**Status.** These theorems are self‑contained and standard; they match the uploaded statements and proofs.
