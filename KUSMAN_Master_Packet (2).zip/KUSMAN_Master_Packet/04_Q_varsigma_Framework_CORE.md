
# 04 — Ϙ–ς (Q–varsigma) Framework: Core Lemmas & Status

## What is solid here
- Definition of the category \(\mathbf{MMK}\), its internal logic, and the construction of closure operators
  \(\clos{a},\clos{g},\clos{s},\clos{\ell}\) (algebraic, geometric, spectral, logical) as idempotent, monotone, extensive
  operators (reflectors).
- The coarse‑graining functor \(\Q\) as a composite reflector; idempotence \(\Q^2=\Q\) and functoriality.

### Lemma A (Fixed‑point spectrum of \(\Q\)).
\(\Sigma_\Q(X)=\bigcap_i \Sigma_{\varsigma_i}(X)\) is closed (nonempty for compact \(X\)).

### Lemma B (Tensor additivity).
\(\Q(X\otimes Y)\cong \Q(X)\otimes \Q(Y)\) and likewise for each closure \(\varsigma_i\).

### Lemma C (Stability/Lipschitz).
\(\Q\) is Lipschitz under a chosen metric on \(\mathbf{MMK}\) (e.g., GW‑type), hence continuous.

**Remarks.** Lemma A and the reflector formalism follow from standard categorical logic arguments. Lemma B holds
under independence assumptions (product kernels). Lemma C depends on the chosen metric and cited stability theorems.

## Useful corollaries and operator‑theoretic view (from the notes)
- Monotone contraction for potentials decreasing under closures; finite‑step stabilization if the potential has
  finite image.
- Spectral: \(\Q\) induces an orthogonal projection on \(L^2\) commuting with Markov operators.

**Status.** These fit a coherent categorical picture. Where statements cite external numbered theorems (e.g., strict
convexity/uniqueness of a GW step), their proofs are *referential* rather than reproduced here.
