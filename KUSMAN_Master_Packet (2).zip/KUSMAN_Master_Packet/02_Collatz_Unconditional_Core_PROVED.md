
# 02 — Collatz: Unconditional Core Facts (proved)

This file collects statements about the **accelerated Collatz map** \(T(n)=(3n+1)/2^{\nu(n)}\) on odd integers, that
are true unconditionally.

## Lemma A (Permutation modulo \(2^k\) and geometric valuation law).
For each \(k\ge 1\), \(T \bmod 2^k\) permutes the odd residues, and \(\nu(n)=v_2(3n+1)\) is geometric on odd residues:
\(\Pr(\nu=\ell)=2^{-\ell}\) for \(1\le \ell\le k\) (stable as \(k\to\infty\)).

**Proof (sketch).** \(3\) is invertible modulo \(2^k\); counting residues with \(2^\ell\mid 3n+1\) gives \(\mu(\nu\ge \ell)=2^{1-\ell}\);
difference yields \(2^{-\ell}\).

## Lemma B (Negative expected log step under Haar on odd 2‑adics).
Let \(\Delta(n):=\log T(n) - \log n = \log 3 - \nu(n)\log 2\), with respect to the Haar limit measure on odd residues.
Then \(\mathbb{E}[\Delta]=\log(3/4)<0\) and \(\mathrm{Var}(\Delta)<\infty\).

**Proof.** Using Lemma A, \(\mathbb{E}[\nu]=2\), so \(\mathbb{E}[\Delta]=\log 3 - 2\log 2\).

## Lemma C (Parity‑orientation: no two consecutive \(k=1\) steps).
If \(n\equiv 3\pmod 4\), then \(\nu(n)=1\) and \(T(n)\equiv 1\pmod 4\); therefore \(k=1\) cannot occur twice in a row.

**Proof.** Compute modulo 4: \(3n+1\equiv 3\cdot 3+1\equiv 2\pmod 4\) when \(n\equiv 3\), hence one factor of 2; the next odd is \(1\pmod 4\).

**Status.** These facts are classical and require no additional assumptions. They are the robust baseline for any
macro‑descent argument.
