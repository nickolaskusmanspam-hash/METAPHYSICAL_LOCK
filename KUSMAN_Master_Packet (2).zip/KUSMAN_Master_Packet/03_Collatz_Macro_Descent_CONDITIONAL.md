
# 03 — Collatz Macro‑Descent: Conditional Theorem + Gap Checklist

The uploaded draft frames a finite **adjoint automaton** over small‑\(k\) steps with edge weights bounding changes in
a bit‑height \(S=\lfloor\log_2 n\rfloor\). It **assumes** that after sufficient refinement the automaton has **strictly
negative cycle mean**, yielding a potential \(h\) with a per‑edge gap \(\eta>0\). Under that **certificate**, one proves
uniform bounds on small‑\(k\) blocks and descent across macro‑steps.

## Conditional Theorem (Macro‑descent ⇒ eventual collapse).
Assume a refined finite automaton \(\mathcal G'\) for small‑\(k\) transitions with weight bounds \(w'\) and a potential
\(h:X'\to\mathbb R\) such that for all edges \(e':x'\to y'\): \(h(y')-h(x')\ge w'(e')+\eta\) for some \(\eta>0\), and let
\(D>0\) be the guaranteed drop of \(S\) on trigger steps (\(k\ge 3\)). Then every trajectory admits macro‑steps whose
net effect strictly decreases \(S\), hence the odd trajectory collapses to \(1\).

**Proof (sketch).** Sum the per‑edge inequalities over a maximal small‑\(k\) block to get
\(\sum \Delta S \le h(x'_t)-h(x'_0)-t\eta \le \Delta h - t\eta\), bounding both overshoot and length by \(\Delta h/\eta\).
Appending the trigger forces a net drop; iterate.

## Gap Checklist (what must be *constructed/verified* to make this unconditional).
1. **Construction of \(\mathcal G'\)** with sound uniform weight bounds \(w'\) covering *all* odd integers.
2. **Refinement termination:** exhibit a finite refinement where **every** directed cycle has negative mean.
3. **Certificate extraction:** compute \(h\), \(\eta\), and \(\Delta h\) explicitly.
4. **Trigger drop \(D>0\)**: rigorous lower bound uniform in all cases (easy analytically).
5. **Global coverage:** show projections \(\pi\) from integers to \(X'\) introduce no leakage of cases.
6. **Independent cross‑check:** machine‑verifiable Karp maximum‑cycle‑mean check on the final \(\mathcal G'\).

**Status.** Without an explicit negative‑cycle‑mean certificate, the proof remains **conditional**. The packet includes
only unconditional lemmas in file 02 and marks the macro‑descent as conditional pending (1)–(6).
