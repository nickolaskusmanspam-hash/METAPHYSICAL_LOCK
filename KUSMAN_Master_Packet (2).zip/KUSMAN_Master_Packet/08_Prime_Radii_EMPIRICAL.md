
# 08 — Prime “Quantized Radii”: Empirical Summary

The analysis embeds the first \(N=5000\) primes by a gap‑based angular map with wraps \(=997\) and a cross‑strip
offset (modulus \(=210\)), and compares radius distributions against three nulls (shuffled primes, constrained odd
integers with matching residues, unconstrained odd integers).

- **Finding:** prominent, nearly evenly spaced radial levels appear for primes, absent in controls.
- **Stats:** KS tests (global and rolling) decisively reject equivalence; lagged increment tests show systematic
  differences.

**Status.** Empirical/statistical; interesting and well‑documented as such. No number‑theoretic theorem is claimed.
