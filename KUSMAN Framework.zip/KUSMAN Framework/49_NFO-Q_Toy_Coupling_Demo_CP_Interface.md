# 49 — NFO–Ϙ Toy Coupling Demo (Safe CP Interface to a Markov Chain)
**Version:** 1.0  
**Date:** 2025-10-08  
**Series:** KUSMAN Framework — Core Verification Series v1.6

---

## 1. MMK process Y: finite Markov chain
Let Y be a Markov chain on m states with transition K_Y (row‑stochastic), Lyapunov Φ_Y(p)=KL(p || π) where π is the stationary distribution.

## 2. CP‑coupling induced by ψ* ∈ Fix(Q)
Define a linear map P_ψ on probabilities by bandlimiting in the eigenbasis of K_Y: keep first r left eigenvectors; project p → P_ψ p. Then set
\[
K'_Y = (1−λ) K_Y + λ P_ψ, \quad 0<λ\ll1.
\]
P_ψ is doubly‑stochastic (nonexpansive in total variation), hence **completely positive** on diagonal density matrices.

**Lemma (Safe descent).** For small λ, Φ_Y decreases under K'_Y at least as fast as under K_Y.

*Sketch.* Nonexpansiveness of P_ψ and convexity of KL yield the inequality; spectral gap of K_Y controls the margin.

---

## 3. DMR certificate
Report (i) spectral gap of K_Y, (ii) projection rank r, (iii) coupling λ. Thresholds ensuring safe descent: (gap ≥ θ), (r ≤ r_max), (λ ≤ λ_max(θ)).

---

## 4. Minimal Python (reference)
```python
import numpy as np

def cp_coupling(KY, r, lam):
    w, VL = np.linalg.eig(KY.T)       # left eigenvectors as columns of VL
    # order by |w| descending
    idx = np.argsort(-np.abs(w))
    VL = VL[:, idx]
    # projector onto first r left-eigenvectors (orthonormalize)
    QL, _ = np.linalg.qr(VL[:, :r])
    P = QL @ QL.T                     # projector in prob space
    Kp = (1-lam)*KY + lam*P
    # renormalize rows to be stochastic
    Kp = Kp / Kp.sum(axis=1, keepdims=True)
    return Kp
```

---

**Footer:**  
— KUSMAN Framework — Core Verification Series v1.6
