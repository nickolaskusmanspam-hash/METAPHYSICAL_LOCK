
# KUSMAN — Core Lemmas & Proof Sketches (v1)

This bundle collects the *internally provable* statements that are stable across your documents, with short proof sketches and explicit scope. The results fall into three buckets: (A) internal logic of the `MMK` category, (B) Ϙ–ς (Q–sigma) categorical/metric structure, and (C) unconditional structural lemmas used by NEAM/Collatz–Prime.

---

## A. Internal Logic of `MMK`

### A1. Existence of adjoints to pullback (hyperdoctrine structure)
**Theorem.** For every morphism `F: X → Y` in `MMK`, the predicate pullback `F* : Pred(Y) → Pred(X)` admits left and right adjoints
\[
(\exists_F \varphi)(y) = \operatorname*{ess\,sup}_{x \in F^{-1}(y)} \varphi(x), \qquad
(\forall_F \varphi)(y) = \operatorname*{ess\,inf}_{x \in F^{-1}(y)} \varphi(x).
\]
**Sketch.** Standard Borel + measurable fibers give Suslin measurability of fibrewise `sup/inf`. Adjunction is pointwise from the `sup/inf` laws.

### A2. Beck–Chevalley for `∃, ∀`
**Theorem.** For any pullback square in `MMK`,
\[
\exists_{\pi_Z}\,\pi_X^* = G^*\,\exists_F, \qquad
\forall_{\pi_Z}\,\pi_X^* = G^*\,\forall_F.
\]
**Sketch.** Fibres of `F` over `y` biject those of `π_Z` over any `z` with `G(z)=y`. Fibrewise `sup/inf` commute with pullback along the bijection.

### A3. Frobenius reciprocity
**Theorem.** For all predicates `φ` on `X` and `ψ` on `Y`,
\[
\exists_F(\varphi \wedge F^*\psi) = (\exists_F \varphi) \wedge \psi, \qquad
\forall_F(\varphi \vee F^*\psi) = (\forall_F \varphi) \vee \psi.
\]
**Sketch.** Pointwise identities: `sup_x min(α(x),c) = min(sup_x α(x),c)` and dual for `inf/max`.

---

## B. The Ϙ–ς Framework (Q–sigma) — categorical/metric structure

### B1. Fixed–Point Spectrum
**Lemma.** For the idempotent reflector `Q = ς_a ∘ ς_g ∘ ς_s ∘ ς_ℓ`, the fixed-point set
\[
\Sigma_Q(X) = \bigcap_i \{x : ς_i(x)=x\}
\]
is closed (nonempty for compact carriers).

### B2. Additivity under tensor products (strong monoidality)
**Lemma.** `Q(X ⊗ Y) ≅ Q(X) ⊗ Q(Y)`. Each closure `ς_i` distributes over `⊗`.

### B3. Lipschitz stability
**Lemma.** There exists `C>0` with `d_MMK(Q(X), Q(Y)) ≤ C·d_MMK(X,Y)`; hence `Q` is continuous.

### B4. Finite convergence (idempotence)
**Lemma.** If `Q` is implemented by strictly convex entropic GW followed by idempotent closures, then `Q^(n)(X)=Q(X)` for all `n≥1`.

### B5. Monotone contraction (Lyapunov law)
**Lemma.** If each `ς_i` decreases a monotone potential `Ψ_X`, then `Ψ_X(Q(x)) ≤ Ψ_X(x)` with equality iff `x` is `Q`-fixed.

### B6. Adjoint triangle (universal projection property)
**Lemma.** Every `F: X→Y` factors uniquely through `Q`: there is a unique `\bar F: Q(X)→Q(Y)` with `F = i_Y ∘ \bar F ∘ i_X^{-1}` on the reflective image.

### B7. Strong monoidal reflector (categorical form)
**Lemma.** The natural maps `Q(X)⊗Q(Y) → Q(X⊗Y)` and `I→Q(I)` form a monoidal natural isomorphism.

### B8. Information monotonicity
**Lemma.** For any observable `Y=F(X)` and `Z=Q(X)`, one has `I(X;Z) ≥ I(Y; Q(Y))`, with equality iff `F` factors through `Q`.

### B9. Spectral factorization
**Lemma.** The Markov operator `T_K` on `L^2(X,μ)` decomposes as
\[
T_K = T_{Q(K)} \oplus (T_K - Q(K))
\]
with the `Q`-induced orthogonal projector commuting with `T_K`.

---

## C. Structural lemmas used by NEAM / Collatz–Prime

### C1. Odd 2-adic valuation law for accelerated Collatz
**Lemma.** For `T(n) = (3n+1)/2^{ν(n)}` on odd integers, with uniform measure on odd residues mod `2^k`, the valuation `ν` is `Geom(1/2)` (exact, independent of `k`).

### C2. Log-scale contraction (unconditional average)
**Lemma.** `E[log T(n) - log n] = log(3/4) < 0` under Haar measure on odd `2`-adics; variance finite.

### C3. Invariance of Haar measure and isometry of the transfer operator
**Lemma.** `μ` (Haar on `Z_2^×`) is invariant for `T`; `L_C f = f∘T` is isometric with spectral radius `1`.

### C4. Permutation parity invariant (orientation signature)
**Lemma.** The sign of the permutation induced by `T mod 2^k` stabilizes along a cofinal subsequence; the limit is an orientation/Klein discriminator in the NEAM embedding.

### C5. Prime smoothing kernel — top eigenvalue near `1` (averaged)
**Lemma.** The locally averaged kernel `L_P` on a large log-window has a top eigenvalue `1+o(1)` with nonnegative near-constant eigenfunction.

### C6. Spectral perturbation coupling (averaged)
**Lemma.** On a common log-window, the log-projected Collatz kernel and the prime kernel admit a coupling whose `L^1` discrepancy → 0 as the window drifts to infinity; hence top spectra/invariants match up to `o(1)`.

---

## D. Empirical findings (safe to cite; not theorems)

- **Prime radii quantization.** In a gap-based angular/cross-strip embedding, the first `N=5000` primes concentrate on discrete radial levels with spacing `Δr ≈ 0.126 ± 0.002`, decisively different from shuffled and synthetic controls (global KS `p ≪ 10^{-15}`).
- **Motif reinforcement in evolutionary logs.** High-frequency 2- and 3-token motifs grow monotonically; “twist hubs” act as attractors; dictionary of proven mutations grows; language compresses around a stable core.

---

### Notes on scope
These items are *provable within the KUSMAN/MMK formalism or are purely empirical*. Major claims about Collatz, P vs NP, RH, or fluid regularity belong in the **Conditional Master Theorems** pack (see separate file) with their hypotheses stated explicitly.
