# 47 — NFO–Ϙ Toy Model on a Finite Graph (Fully Discrete)
**Version:** 1.0  
**Date:** 2025-10-08  
**Series:** KUSMAN Framework — Core Verification Series v1.6

---

## Goal
A minimal, concrete sandbox that realizes the NFO–Ϙ pipeline end‑to‑end on a **finite undirected graph** G=(V,E). This is purely mathematical and internal to KUSMAN.

---

## 1. Discrete MMK object
- **Carrier:** |X| = ℂ^{|V|} (a complex field ψ on vertices).
- **Measure:** Gaussian with covariance C = (I + τ L_G)^{−1}, L_G the combinatorial Laplacian; τ>0.
- **Kernel:** K_ε = exp(−ε L_G) (heat on the graph).
- **Metric:** d(ψ,φ) = ||ψ−φ||_2.

---

## 2. Ϙ–ς closures (discrete)
Define Q = σ_top ∘ σ_gauge ∘ σ_ent ∘ σ_ℓ.

1) **σ_top (harmonic/topology projector).** Decompose ψ = ψ_harm + ψ_⊥ via the graph Hodge decomposition. For a connected graph, ker L_G = span{1}. Set the harmonic coefficient to a canonical value (e.g., zero mean): σ_top(ψ) = ψ − (⟨ψ,1⟩/⟨1,1⟩)·1.

2) **σ_gauge (U(1) phase & scale).** Normalize global phase and magnitude: σ_gauge(ψ) = ψ · e^{−i arg(⟨ψ, u_1⟩)} / max(1, ||ψ||_2/Λ), where u_1 is the Fiedler or any fixed reference eigenvector; Λ>0 is an admissibility radius.

3) **σ_ent (bandlimit/PSD).** Spectral bandlimit to the first k eigenvectors of L_G: ψ = Σ_j a_j u_j → σ_ent(ψ)=Σ_{j=1}^k a_j u_j. This enforces “nonlocal correlation positivity” in the toy setting by discarding high-frequency modes.

4) **σ_ℓ (admissibility clip).** Clip any residual overflow: σ_ℓ(ψ) = ψ · min(1, Λ/||ψ||_2).

All σ_* are idempotent and commute on their domains ⇒ Q^2=Q (Ϙ–ς stability).

---

## 3. Lyapunov potential
Define
\[
Ψ(ψ) = α ||ψ − σ_ent ψ||_2^2 + β ||ψ − σ_gauge ψ||_2^2 + γ ||ψ − σ_top ψ||_2^2 + δ ||K_ε ψ − ψ||_2^2,
\]
with α,β,γ,δ>0. Ψ measures incoherence: high‑freq leakage, gauge drift, topological offset, and dynamical roughness.

---

## 4. Iteration
**Update:** ψ ← Q(K_ε ψ).  
**Stop:** when Ψ decreases by < tol or after T steps.  
**Guarantee (finite‑dimensional Lyapunov):** strict drop unless ψ is Q‑fixed ⇒ stabilization in finitely many steps.

---

## 5. Minimal Python (reference)
```python
import numpy as np

def graph_laplacian(adj):
    deg = np.diag(adj.sum(1))
    return deg - adj

def spectral_project(v, U, k):
    # U: eigenvectors columns; project to first k modes
    a = U.T @ v
    a[k:] = 0.0
    return U @ a

def Q_closure(psi, U, ones, k, Lambda):
    # sigma_top
    psi = psi - (psi.conj() @ ones / (ones.conj() @ ones)) * ones
    # sigma_gauge (phase, norm)
    ref = U[:,1] if U.shape[1] > 1 else ones/np.linalg.norm(ones)
    phase = np.angle((psi.conj() @ ref))
    psi = psi * np.exp(-1j*phase)
    nrm = np.linalg.norm(psi)
    if nrm > Lambda: psi = psi * (Lambda / nrm)
    # sigma_ent (bandlimit)
    psi = spectral_project(psi, U, k)
    # sigma_l (clip)
    nrm = np.linalg.norm(psi)
    if nrm > Lambda: psi = psi * (Lambda / nrm)
    return psi

def iterate(adj, psi0, eps=0.1, k=5, Lambda=1.0, T=200, tol=1e-9, alphas=(1,1,1,1)):
    L = graph_laplacian(adj)
    lam, U = np.linalg.eigh(L)            # U columns are eigenvectors
    ones = np.ones(len(adj), dtype=complex)
    psi = psi0.astype(complex).copy()
    alpha,beta,gamma,delta = alphas
    def Psi(psi):
        # terms as defined (computed via single-pass closures)
        import copy
        from numpy.linalg import norm
        # reuse pieces
        psi_ent = spectral_project(psi, U, k)
        # top
        psi_top = psi - (psi.conj() @ ones / (ones.conj() @ ones)) * ones
        # gauge
        ref = U[:,1] if U.shape[1] > 1 else ones/np.linalg.norm(ones)
        phase = np.angle((psi.conj() @ ref))
        psi_g = psi * np.exp(-1j*phase)
        nrm = np.linalg.norm(psi_g)
        if nrm > Lambda: psi_g = psi_g * (Lambda / nrm)
        # heat
        K = U @ np.diag(np.exp(-eps*lam)) @ U.T
        return (alpha*norm(psi-psi_ent)**2 +
                beta*norm(psi-psi_g)**2 +
                gamma*norm(psi-psi_top)**2 +
                delta*norm(K @ psi - psi)**2)
    hist = [Psi(psi)]
    for t in range(T):
        # heat step
        K = U @ np.diag(np.exp(-eps*lam)) @ U.T
        psi = K @ psi
        # Q closure
        psi = Q_closure(psi, U, ones, k, Lambda)
        val = Psi(psi)
        hist.append(val)
        if abs(hist[-2]-hist[-1]) < tol: break
    return psi, np.array(hist)
```

---

**Footer:**  
— KUSMAN Framework — Core Verification Series v1.6
