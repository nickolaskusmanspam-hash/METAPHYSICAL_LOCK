# Finite Automaton Certificate — Collatz Small‑k Drift

_Generated: 2025-10-10 23:31:50 UTC_

This one‑pager summarizes the verification certificate for the small‑k Collatz automaton and spells out the exact quantities a third party needs to check.

## Files & Checksums
- `dmr_m6_report.json` — SHA256: `a4168a6821dc1249ce1919dd2aaae1c789e7d64305512e8ea61cee43f92196e6`
- `dmr_m6_leaves.jsonl` — SHA256: `9f47537cfacb27cf933f993e47a15f91d5279dbfa7389e032b51a44fa0e63353`
- **Graph fingerprint (from leaves)** — SHA256: `eeb089b2bef258b3a1641bc26643f8637bd4b9ffbee34bd296101151e691c1cb`

## Automaton Summary (from `leaves`)
- Nodes (distinct `(root_r, k, u)` endpoints): **3584**
- Edges: **1792**
- Distinct `k` values: **3**  → `[1, 2, 3]`
- Distinct `root_r` values: **28**
- Edge weight stats: min **0.015625**, mean **0.015625**, max **0.015625**

## Max Cycle Mean / Feasibility (from `report`)
- Feasible (no **positive** cycle means): **True**
- Reported max‑cycle‑mean deviation (≤0 desired): **0.0**

> **Interpretation:** For the strict (PG‑gap) route, require `worst_dev ≤ -η` with some `η>0`. For the non‑strict route, feasibility with `worst_dev ≤ 0` suffices **if** the potential range `Δh` is smaller than the trigger drop `D`.

## Potential Range and Trigger Drop
- `Δh` (potential range): _MISSING in leaves_ — include `h` values per node to compute this (or provide `Δh` in the report).
- Trigger drop `D` (uniform lower bound on bit‑height drop for trigger steps `k≥3`): **<fill>** (e.g., `D ≥ 1`).

### Macro‑Step Inequality (to be verified)
For each small‑k block followed by a trigger:
```
S(after trigger) − S(before block) ≤ Δh − D
```
Therefore a uniform negative drift per macro‑step holds if `Δh < D`. Define the margin `ε := D − Δh`.

## Certificate Summary (copy‑paste block)
```json
{
  "artifact": "collatz_smallk_certificate",
  "generated_utc": "2025-10-10 23:31:50 UTC",
  "report_sha256": "a4168a6821dc1249ce1919dd2aaae1c789e7d64305512e8ea61cee43f92196e6",
  "leaves_sha256": "9f47537cfacb27cf933f993e47a15f91d5279dbfa7389e032b51a44fa0e63353",
  "graph_fingerprint_sha256": "eeb089b2bef258b3a1641bc26643f8637bd4b9ffbee34bd296101151e691c1cb",
  "nodes_count": 3584,
  "edges_count": 1792,
  "k_values": [
    1,
    2,
    3
  ],
  "root_r_count": 28,
  "edge_weight_stats": {
    "min": 0.015625,
    "mean": 0.015625,
    "max": 0.015625
  },
  "feasible_no_positive_cycles": true,
  "max_cycle_mean_deviation": "0.0",
  "strict_gap_eta": "<fill or 0>",
  "potential_range_Delta_h": "<fill>",
  "trigger_drop_D": "<fill>",
  "macro_step_margin_epsilon": "<compute: D - Delta_h>"
}
```

## Reproducibility Checklist
1. Verify file SHA256 checksums and graph fingerprint match the above.
2. Recompute max‑cycle‑mean (Karp) on the canonical edge list from `leaves.jsonl`; confirm the reported deviation.
3. If strict route: confirm `η>0` such that all edges satisfy `h(y) − h(x) ≥ w(e) + η` and all cycles have mean ≤ −η.
4. If non‑strict route: compute `Δh` and confirm `Δh < D`; parity/orientation ensures triggers occur ⇒ global descent.
5. Export the final tuple `(report_sha, leaves_sha, graph_hash, η or Δh, D)` as the human‑readable certificate.

---
_Tip: include a small script that canonicalizes the leaves (sort keys; one JSON per line) before hashing, so third‑party hashes match exactly._