
#!/usr/bin/env python3
"""
verify_collatz_certificate.py

One-shot verifier for the finite automaton certificate used in the KUSMAN Collatz macro-descent argument.

Features
- Canonicalizes `leaves.jsonl` (select keys, sorted) and emits a graph fingerprint SHA256.
- Recomputes Karp's maximum cycle mean (MCM) on the weighted digraph.
- Extracts potential values (if present) to compute Δh.
- Checks either the strict route (η>0 ⇒ MCM ≤ −η) or the non-strict route (Δh < D).
- Produces a machine-readable summary JSON and a human-readable TXT.
"""

import argparse, json, hashlib, sys, os, math, statistics, datetime
from collections import defaultdict

KEEP_KEYS = ["root_r", "k", "u_start", "u_end", "weight"]

def sha256_of_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()

def canonicalize_leaves(in_path, out_path):
    edges = []
    with open(in_path, "r", encoding="utf-8") as fin:
        for i, line in enumerate(fin, 1):
            line = line.strip()
            if not line:
                continue
            obj = json.loads(line)
            # canonical edge (structural keys only)
            canon = {k: obj.get(k) for k in KEEP_KEYS}
            edges.append(canon)
    # sort
    edges.sort(key=lambda e: (e.get("root_r"), e.get("k"), e.get("u_start"), e.get("u_end")))
    # write
    with open(out_path, "w", encoding="utf-8") as fout:
        for e in edges:
            fout.write(json.dumps(e, sort_keys=True) + "\n")
    # fingerprint
    h = hashlib.sha256()
    with open(out_path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return edges, h.hexdigest()

def load_edges_with_h(leaves_path):
    edges_raw = []
    with open(leaves_path, "r", encoding="utf-8") as fin:
        for line in fin:
            line = line.strip()
            if not line:
                continue
            obj = json.loads(line)
            edges_raw.append(obj)
    return edges_raw

def build_graph(edges):
    """Map nodes to indices; return (index_map, rev_map, adj) where adj[u] = list of (v, w)."""
    nodes = {}
    rev = []
    def node_id(tag, r, k, u):
        # tag is "start"/"end" but we treat nodes uniformly by (r,k,u)
        return (r, k, u)
    # collect nodes
    for e in edges:
        r, k = e.get("root_r"), e.get("k")
        u0, u1 = e.get("u_start"), e.get("u_end")
        for u in (u0, u1):
            key = node_id("n", r, k, u)
            if key not in nodes:
                nodes[key] = len(nodes)
                rev.append(key)
    n = len(nodes)
    adj = [[] for _ in range(n)]
    for e in edges:
        r, k = e.get("root_r"), e.get("k")
        u0, u1 = e.get("u_start"), e.get("u_end")
        w = e.get("weight")
        if w is None:
            continue
        a = nodes[(r, k, u0)]
        b = nodes[(r, k, u1)]
        adj[a].append((b, float(w)))
    return nodes, rev, adj

def karp_max_cycle_mean(adj):
    """
    Returns (mu, n) where mu is the maximum cycle mean of a weighted digraph.
    Implementation follows Karp's algorithm. Complexity ~ O(n*m).
    """
    n = len(adj)
    if n == 0:
        return float("-inf"), 0
    # dp[k][v] = max weight of a walk of exactly k edges ending at v
    # initialize
    dp = [[float("-inf")] * n for _ in range(n + 1)]
    for v in range(n):
        dp[0][v] = 0.0
    # relax
    for k in range(1, n + 1):
        row = dp[k]
        prev = dp[k - 1]
        for u in range(n):
            wu = prev[u]
            if wu == float("-inf"):
                continue
            for v, w in adj[u]:
                if wu + w > row[v]:
                    row[v] = wu + w
    # compute mu
    mu = float("-inf")
    for v in range(n):
        best = float("inf")
        if dp[n][v] == float("-inf"):
            continue
        for k in range(n):
            if dp[k][v] == float("-inf"):
                continue
            val = (dp[n][v] - dp[k][v]) / (n - k)
            if val < best:
                best = val
        if best > mu:
            mu = best
    return mu, n

def extract_delta_h(edges_raw):
    """Pulls any present h values; returns (Δh or None, present_fields: set)."""
    h_vals = []
    present = set()
    for e in edges_raw:
        for key in ("h_start", "h_end", "h"):
            if key in e:
                present.add(key)
                val = e.get(key)
                if isinstance(val, (int, float)):
                    h_vals.append(float(val))
    if h_vals:
        return (max(h_vals) - min(h_vals)), present
    return (None, present)

def main():
    ap = argparse.ArgumentParser(description="Verify Collatz small-k certificate.")
    ap.add_argument("--leaves", required=True, help="Path to dmr_m6_leaves.jsonl")
    ap.add_argument("--report", required=False, help="Path to dmr_m6_report.json")
    ap.add_argument("--out-dir", default="cert_output", help="Directory for outputs (created if missing)")
    ap.add_argument("--trigger-drop", type=float, default=None, help="D: uniform trigger drop bound (e.g., 1.0)")
    ap.add_argument("--strict-eta", type=float, default=None, help="η: strict gap; require MCM ≤ −η if provided")
    args = ap.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)
    # Canonicalize leaves
    canon_path = os.path.join(args.out_dir, "leaves_canonical.jsonl")
    edges_canon, graph_fingerprint = canonicalize_leaves(args.leaves, canon_path)
    leaves_sha = sha256_of_file(args.leaves)
    canon_sha = sha256_of_file(canon_path)

    # Build graph and run Karp
    nodes, rev, adj = build_graph(edges_canon)
    mu, n = karp_max_cycle_mean(adj)  # maximum cycle mean

    # Load raw edges for Δh
    edges_raw = load_edges_with_h(args.leaves)
    delta_h, h_fields = extract_delta_h(edges_raw)

    # Load report if present
    report = None
    report_sha = None
    worst_dev = None
    feasible = None
    if args.report and os.path.exists(args.report):
        report_sha = sha256_of_file(args.report)
        with open(args.report, "r", encoding="utf-8") as f:
            try:
                report = json.load(f)
                worst_dev = report.get("worst_dev")
                feasible = report.get("ok")
            except Exception as e:
                report = {"_error": f"Failed to parse report: {e}"}

    # Decide checks
    strict_ok = None
    strict_margin = None
    if args.strict_eta is not None:
        strict_ok = (mu <= -args.strict_eta)
        strict_margin = (-args.strict_eta) - mu  # ≥ 0 iff strict_ok

    nonstrict_ok = None
    nonstrict_margin = None
    if args.trigger_drop is not None and delta_h is not None:
        nonstrict_ok = (delta_h < args.trigger_drop)
        nonstrict_margin = args.trigger_drop - delta_h

    # Summaries
    info = {
        "generated_utc": datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC"),
        "inputs": {
            "leaves_path": args.leaves,
            "leaves_sha256": leaves_sha,
            "report_path": args.report,
            "report_sha256": report_sha,
        },
        "canonicalization": {
            "canonical_leaves_path": canon_path,
            "canonical_leaves_sha256": canon_sha,
            "graph_fingerprint_sha256": graph_fingerprint,
        },
        "graph_stats": {
            "node_count": len(nodes),
            "edge_count": sum(len(lst) for lst in adj),
        },
        "karp_max_cycle_mean": {
            "mu": mu,
            "interpretation": "Require mu ≤ 0 for non-positive cycles; for strict, mu ≤ −η."
        },
        "report_fields": {
            "feasible_no_positive_cycles": feasible,
            "worst_dev": worst_dev,
        },
        "potential_range": {
            "Delta_h": delta_h,
            "present_fields": sorted(list(h_fields)),
        },
        "checks": {
            "strict": {
                "eta": args.strict_eta,
                "ok": strict_ok,
                "margin": strict_margin,
            },
            "nonstrict": {
                "trigger_drop_D": args.trigger_drop,
                "ok": nonstrict_ok,
                "margin": nonstrict_margin,
            }
        }
    }

    out_json = os.path.join(args.out_dir, "certificate_summary.json")
    out_txt = os.path.join(args.out_dir, "certificate_summary.txt")

    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(info, f, indent=2)

    # "Signed" summary = SHA256 of the JSON for attestation
    summary_sha = sha256_of_file(out_json)

    with open(out_txt, "w", encoding="utf-8") as f:
        f.write("# Collatz Small-k Certificate — Verification Summary\n\n")
        f.write(f"Generated (UTC): {info['generated_utc']}\n")
        f.write(f"Summary SHA256: {summary_sha}\n\n")
        f.write("## Inputs\n")
        f.write(f"- leaves: {args.leaves}\n  - SHA256: {leaves_sha}\n")
        if args.report:
            f.write(f"- report: {args.report}\n  - SHA256: {report_sha}\n")
        f.write("\n## Canonicalization\n")
        f.write(f"- canonical leaves: {canon_path}\n  - SHA256: {canon_sha}\n")
        f.write(f"- graph fingerprint SHA256: {graph_fingerprint}\n")
        f.write("\n## Graph stats\n")
        f.write(f"- nodes: {info['graph_stats']['node_count']}\n")
        f.write(f"- edges: {info['graph_stats']['edge_count']}\n")
        f.write("\n## Karp max cycle mean\n")
        f.write(f"- mu (max cycle mean): {mu}\n")
        f.write("  - require mu ≤ 0 for non-positive cycles; for strict gap, mu ≤ −η\n")
        f.write("\n## Report fields (if provided)\n")
        f.write(f"- feasible: {feasible}\n")
        f.write(f"- worst_dev: {worst_dev}\n")
        f.write("\n## Potential range & trigger\n")
        f.write(f"- Δh: {delta_h}\n")
        f.write(f"- trigger D (user arg): {args.trigger_drop}\n")
        if args.strict_eta is not None:
            f.write(f"- strict η (user arg): {args.strict_eta}\n")
        f.write("\n## Checks\n")
        if args.strict_eta is not None:
            f.write(f"- strict route ok? {strict_ok}  (margin = {strict_margin})\n")
        if args.trigger_drop is not None and delta_h is not None:
            f.write(f"- non-strict route ok? {nonstrict_ok}  (margin = {nonstrict_margin})\n")
        f.write("\n# End\n")

    print(out_json)
    print(out_txt)
    print(summary_sha)

if __name__ == "__main__":
    main()
