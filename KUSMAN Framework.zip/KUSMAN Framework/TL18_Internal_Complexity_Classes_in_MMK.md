# TL18 — Internal Complexity Classes in \MMK (P, NP, …) and Q-Canonicalization
**Author:** Aster Lumen  
**Date:** 2025-10-09  
**Series:** KUSMAN Framework — Tightening Partials

---

## Goal
Define **decision/search problems** and **resources** natively in \MMK, formalize classes like `P` and `NP` internally, and relate them to **Q-canonicalization** (ϛ_a and Q as contraction/normalization). Provide DMR–Comp certificates.

---

## 1. Problem objects & algorithms as kernels
- A **problem** is a predicate object `(X, χ)` with `χ: X→Ω_c` (crisp).  
- An **algorithm** is a Markov kernel `A: X↠Y` plus a decision map to `{0,1}`; **runtime** measured in expected steps under a size measure `|·|` and cost kernel.  
- **Witness relation** `W ⊆ X×Z` is an MMK subobject; verification is a kernel `V: X×Z↠{0,1}` with bounded cost.

---

## 2. Classes (internal)
- **Pᴹᴹᴷ**: there exists a family of algorithms `(A_n)` with expected cost poly(n) deciding `χ` on inputs of size `n`.  
- **NPᴹᴹᴷ**: there exists a polynomially-bounded witness object `Z_n` and verifier `V_n` such that acceptance marginalizes some `z∈Z_n`.

**Closure properties.** Under `ϛ_a` (automaton closure), problem presentations canonically simplify; reductions are 1-Lipschitz in TL1 metrics ⇒ completeness notions stable under mild perturbations.

---

## 3. Q-canonicalization effect
**Theorem 18.1 (Normalization).** If a problem admits `ϛ_a`-canonical forms computable in polytime (with respect to size), then any Karp reduction can be lifted to operate on canonical forms without asymptotic overhead.  
**Corollary.** In domains with full `ϛ_a` canonicalization, `Pᴹᴹᴷ` is closed under these reductions; some NP–P separations reduce to absence of polynomial canonical forms.

---

## 4. Certificates — DMR–Comp
- Size/cost model specification  
- Canonicalization existence (ϛ_a) & complexity  
- Reduction stability (Lipschitz constants in TL1)  
- Witness/Verifier bounds for NPᴹᴹᴷ instances

**Footer:** — KUSMAN Tightening Partials v1.1
