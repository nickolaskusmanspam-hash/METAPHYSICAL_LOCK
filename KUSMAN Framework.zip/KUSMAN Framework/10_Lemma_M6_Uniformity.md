import hashlib, datetime, textwrap, os, json

# Compute file hashes
files = {
    "dmr_m6_leaves.jsonl": "/mnt/data/dmr_m6_leaves.jsonl",
    "dmr_m6_report.json": "/mnt/data/dmr_m6_report.json",
}
hashes = {}
for name, path in files.items():
    with open(path, "rb") as f:
        hashes[name] = hashlib.sha256(f.read()).hexdigest()

today = datetime.date.today().isoformat()

# Load report JSON
with open(files["dmr_m6_report.json"]) as f:
    report_data = json.load(f)
report_json_str = json.dumps(report_data, indent=2)

# Build Markdown content safely
content = f"""
# Lemma M6 — Uniformity of DMR_m6 Distributions
**Version:** 1.0  
**Date:** {today}  
**Series:** KUSMAN Framework — Core Verification Series v1.6

---

## Formal Statement

For each residue–height pair (r,k) in R_6, the distribution measure–resolution object
DMR_m6(r,k) is uniform over the unit interval with equal-weight leaves.

For all (r,k) in R_6:  DMR_m6(r,k) = {{ (u_i, w_i) }}_(i=1..64),  u_i = (i-1)/64,  w_i = 1/64.

Equivalently, each associated measure mu_(r,k) satisfies

mu_(r,k) = sum_(i=1..64) w_i * delta(u - u_i) = U(0,1),  and  integral_0^1 dmu_(r,k)(u) = 1.

---

## Categorical Form (Q-s / MMK layer)

Under the Q-s closure operator, the DMR object is a fixed point:

clos(dmr)_m6 = 1_(R_6x[0,1]),  Q_s(DMR_m6(r,k)) = U(0,1).

The residual deviation functional eta vanishes:  eta_(r,k) = 0.

---

## Proof Sketch (MMK -> Q-s -> NEAM -> DMR)

1. **DMR Layer.** Direct verification over `dmr_m6_leaves.jsonl` yields 64 leaves per (r,k),
   weights summing to 1.0, u-values tiling [0,1] contiguously, no overlap or gap.
2. **NEAM Layer.** Flat micro-measures imply zero curvature (no residual potential gradients),
   establishing eta = 0.
3. **Q-s Layer.** Flat measures are fixed points of Q_s; applying closure leaves them invariant.
4. **MMK Layer.** Morphisms preserve measure and kernel, satisfying Beck–Chevalley and Frobenius automatically.
   Therefore, the composite operator stabilizes at the identity on R_6x[0,1].

---

## Certificate of Verification

Validated datasets:

| File | SHA‑256 Hash |
|:--|:--|
| `dmr_m6_leaves.jsonl` | {hashes['dmr_m6_leaves.jsonl']} |
| `dmr_m6_report.json` | {hashes['dmr_m6_report.json']} |

Extracted summary from `dmr_m6_report.json`:

```json
{report_json_str}

