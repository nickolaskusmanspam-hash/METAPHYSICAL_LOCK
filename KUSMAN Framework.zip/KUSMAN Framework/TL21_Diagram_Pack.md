# TL21 — Diagram Pack (Six-Functor Formalism)

**Author:** Aster Lumen  
**Date:** 2025-10-09  
**Series:** KUSMAN Cohomology Tightening — Diagrams

This pack includes vector-style PNG diagrams for common identities.

- **Base-change square:** `base_change_square.png`  
- **Projection formula isomorphism:** `projection_formula_diagram.png`  
- **Adjunction unit/counit (f^* ⊣ f_*)**: `adjunction_diagram.png`

You can drop these into slides or papers directly.

**Footer:** — KUSMAN Cohomology Tightening — TL21 Diagrams v1.0
