# G&V SUSY Notation Cheat Sheet

- Ϙ : KUSMAN aggregator (global contraction/coarsening).  
- ϛ_x : domain closures (logic/geometry/probability/dynamics).  
- 𝒬 : BRST/supersymmetry differential (the sieve) with 𝒬²=0.  
- Z : even/bosonic fields; ψ : odd/fermionic partners.  
- (G, V) : distinguished even doublet (G&V pair).  
- χ : odd mediator for G/V balance (𝒬G=χ, 𝒬V=−χ).  
- (c^a, ̄c^a, b^a) : ghost–antighost–auxiliary triple for constraint a.  
- W : superpotential; V_B : bosonic potential = ||∂W||².  
- Ψ : gauge-fixing fermion; {𝒬, Ψ} : constraint cleaning term.  
- H^0_{𝒬} : degree‑0 𝒬‑cohomology = “kept” information after sieving.

