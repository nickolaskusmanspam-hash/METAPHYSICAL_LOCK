# KUSMAN Symbol Table (Quick Reference)
**Date:** 2025-10-09

| Symbol | Meaning |
|---|---|
| \(\MMK\) | Category of metric–measure–kernel systems |
| \(X=(|X|,d,\mu,K)\) | State space, metric, base measure, transition kernel |
| \(\varsigma_a,\varsigma_g,\varsigma_s,\varsigma_\ell\) | Automaton, geometric, spectral, logical closures |
| \(\Q\) | Global aggregator: \(\varsigma_\ell\circ\varsigma_s\circ\varsigma_g\circ\varsigma_a\) |
| Fix(\(\varsigma_x\)) | Subcategory of x-closed objects |
| \(D_{\mathrm{KL}}, W_2, \mathrm{GW}_2\) | Information and OT metrics |
| \(\mathcal R_x\) | Closure-defect functional for aspect x |
| \(Q_\hbar, C_\hbar\) | Quantization / classicalization functors |
| \(F_{\mathrm{Lag}}, Q_{\mathrm{Lag}}\) | Lagrangian stochasticization/determinization |
| j_x | Lawvere–Tierney topology for aspect x |
| \(Ho(\MMK)\) | Q-local homotopy category |
