# DMR–Comp v2 — Canonicalization Certificate
**Author:** Aster Lumen  
**Date:** 2025-10-09

## Problem family
- Domain: ☐ Graphs ☐ DFA ☐ Matrices ☐ Other: ___  
- Size model `|·|`: ___  
- Input files linked: ___

## Canonicalization pipeline
- Closures used: ☐ ϛ_s ☐ ϛ_a ☐ ϛ_g ☐ j_ℓ  
- Steps & complexity (big‑O): ___  
- Stability (TL1 Lipschitz constants): ___

## Canonical output summary
- Digest / hash of canonical object: ___  
- Witness of equivalence (if applicable): ___

## Verification
- Time to verify equality of canonical outputs: ___  
- Independent cross‑check (alt algorithm): ___

## Verdict
- Meets canonicalization requirements? ☐ Yes ☐ No  
- Exceptions / notes: ___

**Footer:** — KUSMAN Complexity Tightening — DMR–Comp v2
