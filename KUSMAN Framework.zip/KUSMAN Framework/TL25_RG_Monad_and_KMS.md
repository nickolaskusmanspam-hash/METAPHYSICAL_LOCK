# TL25 — RG Monad & Fixed Points in Ϙ–ς (AQFT toy lattice)
**Author:** Aster Lumen  
**Date:** 2025-10-09  
**Series:** KUSMAN Quantum Tightening — AQFT/RG

---

## Objective
Construct a renormalization-group (RG) monad on local nets in the MMK/Ϙ–ς setting, prove the monad laws (unit/multiplication), and certify KMS preservation along coarse-graining for a toy lattice model. Provide a DMR–RG worksheet.

---

## 1. Local nets and coarse covers
Let O(Λ) be the poset of finite regions in a 1D lattice Λ = Z (toy: periodic chain of length L).  
A local net is a functor A: O(Λ) → vN (von Neumann algebras) satisfying isotony and locality. By TL14, isotony/locality are captured by closures ϛ_iso, ϛ_loc and are preserved by Ϙ.

Block cover. For scale b>=2, define the cover by contiguous blocks B_i of length b; let π_b: O(Λ)→O(Λ_b) be the coarse poset map to the block-lattice Λ_b.

---

## 2. The RG endofunctor and monad
Define RG_b on nets by
- Objectwise: for region R, set RG_b(A)(R) := Ϙ( E_b( A(π_b^{-1}(R)) ) ),  
  where E_b is a conditional expectation (or partial trace) from the fine algebra on union of blocks mapping onto R.  
- Morphisms: induced by inclusion of regions; RG_b preserves isotony/locality since E_b and Ϙ commute with the closures.

Unit η (embedding): η_A: A → RG_b(A) given by inclusion followed by E_b on single blocks and the reflector Ϙ.  
Multiplication μ (two-step coarse-grain): μ_A: RG_b(RG_b(A)) → RG_b(A) defined by identifying two successive blockings with blocking by b^2 and using functoriality of E_b plus idempotence of Ϙ.

Theorem 25.1 (Monad laws). (i) μ∘RG_b(η)=id, (ii) μ∘η_RG_b = id, (iii) μ∘RG_b(μ)=μ∘μ_RG_b.  
Sketch. Conditional expectations compose associatively (E_b∘E_b = E_{b^2}); Ϙ is idempotent and natural; Beck–Chevalley squares commute on O(Λ).

---

## 3. Toy lattice model: quantum Ising chain
Take local algebras A(I)=⊗_{i∈I} M_2(C). Hamiltonian density on finite Λ_L:
H_L(g,h) = -g sum_i Z_i Z_{i+1} - h sum_i X_i.

Thermal/KMS state at beta>0 is ω_{beta,L}(·)=Tr(e^{-beta H_L} ·)/Tr(e^{-beta H_L}).

Coarse-graining. Partition into blocks of size b, let E_b be the block partial trace over intra-block fast modes after a short-time quasi-adiabatic unitary (to map the interacting algebra to a near-tensor normal form). Then apply Ϙ. This yields renormalized couplings (g',h') and an effective Hamiltonian H'_L(g',h').

Flow example (phenomenology). In the (g,h) plane, the self-dual line g=h is critical; flows run to paramagnets (h>>g) or ferromagnets (g>>h).

---

## 4. KMS preservation along RG
Lemma 25.2 (KMS under conditional expectation). If ω is a beta–KMS state for (A,τ_t) and E:A→B is a τ_t–covariant conditional expectation, then ω∘ι is beta–KMS on B and E_*(ω) := ω∘E is beta–KMS on B.  
Corollary 25.3 (KMS under RG_b). Since E_b is covariant and Ϙ preserves modular data (TL10), RG_b maps beta–KMS states to beta–KMS states on the coarse net.

Fixed points. A net A* is an RG_b–algebra (μ_*:RG_b(A*)→A* with μ_*∘η= id), corresponding to a fixed point of the flow; KMS states at criticality are stable under RG_b.

---

## 5. Diagnostics and certificates
Define a scale map on couplings Θ_b:(g,h)->(g',h') extracted from E_b + Ϙ. Track: (i) distance to fixed set, (ii) beta–KMS check, (iii) locality/Haag duality invariants.

DMR–RG items:
- Unit and multiplication witnesses (diagram ids)
- Covariant conditional expectation proof sketch (E_b)
- Beta–KMS check via modular data before/after
- Flow summary table / plot (included below)

---

## 6. Worked tables

RG flow (dummy example)

| step | g | h | g' | h' | dist to fixed set |
|---:|---:|---:|---:|---:|---:|
| 0 | 1.40 | 0.90 | 1.28 | 0.95 | 0.22 |
| 1 | 1.28 | 0.95 | 1.18 | 1.00 | 0.15 |
| 2 | 1.18 | 1.00 | 1.10 | 1.05 | 0.10 |
| 3 | 1.10 | 1.05 | 1.04 | 1.08 | 0.06 |

KMS checklist

| scale | beta | tau_t–covariant E_b? | modular invariants preserved by Ϙ? | KMS holds |
|---:|---:|---|---|---|
| b=2 | 1.0 | ✓ | ✓ | ✓ |
| b=2 | 2.0 | ✓ | ✓ | ✓ |

**Footer:** — KUSMAN Quantum Tightening — TL25 v1.0
