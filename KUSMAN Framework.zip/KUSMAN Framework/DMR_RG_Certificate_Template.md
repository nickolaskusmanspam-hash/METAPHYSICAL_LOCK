# DMR–RG (AQFT RG Monad & KMS Preservation)
**Author:** Aster Lumen  
**Date:** 2025-10-09

## Net and scale
- Lattice/site: ___  
- Block size b: ___  
- Cover π_b and coarse poset map recorded: ___

## RG monad
- Unit η witness (map id): ___  
- Multiplication μ witness (map id): ___  
- Idempotence of Ϙ checked on objects used: ☐

## Conditional expectation and covariance
- E_b defined as: ___  
- tau_t–covariance proof sketch: ___

## KMS
- Initial beta–KMS state: ___  
- Post-RG KMS verification: ☐  
- Modular invariants preserved: spectrum(Δ_ω), J, etc. — notes: ___

## Flow diagnostics
- Coupling map Θ_b(g,h) evaluated steps: ___  
- Distance to fixed set (metric): ___

## Verdict
- RG monad valid and KMS preserved? ☐ Yes ☐ No  
- Exceptions / notes: ___

**Footer:** — KUSMAN Quantum Tightening — DMR–RG v1.0
