import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import re

# -----------------------------
# Load your prime dataset
# -----------------------------
csv_path = "C:/Users/Nick/Desktop/contig_pair_topXss.csv"  # adjust path if needed
df_txt = pd.read_csv(csv_path, header=None, dtype=str)
rows_text = [" ".join([str(x) for x in df_txt.iloc[idx].dropna().values]) for idx in range(len(df_txt))]

pattern = re.compile(
    r"\[(\d+)\]\s*last=(\d+)\s*pred_gap=(\d+)\s*true_gap=(\d+)\s*err=(-?\d+)\s*cand=(\d+)\s*verified=(\d+)\s*\?ver=(\d+)"
)
rows = []
for ln in rows_text:
    m = pattern.match(ln.strip())
    if m:
        rows.append({
            "index": int(m.group(1)),
            "last": int(m.group(2)),
            "pred_gap": int(m.group(3)),
            "true_gap": int(m.group(4)),
            "err": int(m.group(5)),
            "cand": int(m.group(6)),
            "verified": int(m.group(7)),
            "ver": int(m.group(8)),
        })
df = pd.DataFrame(rows).sort_values("index").reset_index(drop=True)

# -----------------------------
# Reconstruct phases
# -----------------------------
N = len(df)
t = np.arange(N, dtype=float)

f1 = 53/116
f2 = 5/116
f3 = 3/25
theta1 = 2*np.pi*f1*t
theta2 = 2*np.pi*f2*t
theta3 = 2*np.pi*f3*t

# η angle from theta3
eta = (np.mod(theta3, 2*np.pi)/(2*np.pi))*(np.pi/2.0)

# Hopf stereographic projection
z1 = np.cos(eta) * np.exp(1j*theta1)
z2 = np.sin(eta) * np.exp(1j*theta2)
u0 = np.real(z1); u1 = np.imag(z1); u2 = np.real(z2); u3 = np.imag(z2)
den = (1.0 - u0) + 1e-12
X = np.column_stack([u1/den, u2/den, u3/den])

# -----------------------------
# Bin into 7 bands
# -----------------------------
bands = 7
edges = np.linspace(0, np.pi/2, bands+1)
band_index = np.digitize(eta, edges) - 1
colors = plt.cm.tab10(np.linspace(0,1,bands))

# Downsample to ~2000 points
step = max(1, N // 7000)
X_sub = X[::step]
band_sub = band_index[::step]

# -----------------------------
# Interactive 3D scatter
# -----------------------------
fig = plt.figure(figsize=(10,8))
ax = fig.add_subplot(111, projection='3d')

for b in range(bands):
    mask = (band_sub == b)
    if np.any(mask):
        pts = X_sub[mask]
        ax.scatter(pts[:,0], pts[:,1], pts[:,2], s=15, alpha=0.7,
                   color=colors[b], label=f"band {b}")

ax.set_title("Hopf stereographic projection (7 bands, ~7000 points)")
ax.set_xlabel("x"); ax.set_ylabel("y"); ax.set_zlabel("z")
ax.legend(loc="upper right")

plt.show()
