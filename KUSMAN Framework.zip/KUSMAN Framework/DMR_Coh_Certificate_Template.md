# DMR–Coh (MMK Cohomology & Derived Functors)
**Author:** Aster Lumen  
**Date:** 2025-10-09

## Site & Cover
- Site `𝒰`, cover `{U_i}`; acyclicity on intersections: ☐ Yes ☐ No

## Coefficient Sheaf
- `𝓕` Q-stable; restrictions commute with `Q`; notes: ___

## Čech vs Derived
- Comparison iso exhibited? ☐ Yes ☐ No  
- Hypercover or standard Čech: ___

## Six-Functor Ops
- `f^*`, `f_*`, (`f_!`, `f^!`), `⊗`, `RHom` used; exactness notes: ___

## Spectral Sequences
- Leray `E2` snapshot (if used); convergence: ___

## Verdict
- Pass? ☐ Yes ☐ No  
- Exceptions: ___
