# TL9 — Ergodic Stability & Spectral Gap Certificates in \MMK
**Uniform mixing bounds via TL1 (info geometry) + TL3 (Q-local homotopy)**

**Version:** 1.0  
**Date:** 2025-10-09  
**Series:** KUSMAN Framework — Immediate Translation Layers

---

## 1. Setup and notions
Let \(X=(|X|,d,\mu,K)\in\MMK\) be a time-homogeneous Markov system with stationary measure \(\pi\).  
Define the Markov operator \(P f(x)=\int f(y)K(x,dy)\) on \(L^2(\pi)\).  
- **Spectral gap:** \(\mathrm{gap}(P)=1-\sup\{ |\lambda|:\lambda\in\mathrm{Spec}(P),\lambda\ne 1\}\).  
- **Poincaré constant:** \(\lambda_2\) s.t. \(\mathrm{Var}_\pi(f)\le (1/\lambda_2)\mathcal E(f,f)\), Dirichlet form \(\mathcal E(f,f)=\langle f,(I-P)f\rangle_\pi\).  
- **Log-Sobolev constant** \(\alpha_{LS}\) with entropy dissipation \(\mathrm{Ent}_\pi(f^2)\le (2/\alpha_{LS})\mathcal E(f,f)\).

---

## 2. Stability under Q and closures
**Lemma TL9.1 (Dirichlet contraction under \(\varsigma_s\)).** Spectral closure reduces the Dirichlet form at fixed variance; hence \(\lambda_2\) and \(\alpha_{LS}\) do not deteriorate under \(\varsigma_s\).  
**Lemma TL9.2 (Q preserves mixing rates up to constants).** There exist universal constants \(c_1,c_2>0\) such that
\[ c_1\,\mathrm{gap}(P_X) \le \mathrm{gap}(P_{\Q X}) \le c_2\,\mathrm{gap}(P_X). \]
*Heuristic:* Q is a 1-Lipschitz contraction in TL1 metrics and merges only fast-trivial modes; slow modes (gap) are preserved up to controlled distortion.

---

## 3. Mixing-time certificates
For total variation or \(\chi^2\) distances, with initial \(\nu\):
\[
\|\nu P^t-\pi\|_{TV} \le \frac{1}{2}\,e^{-\mathrm{gap}\,t}\,\sqrt{\chi^2(\nu\Vert\pi)}.
\]
**Certificate items (DMR-Gap):**  
- Lower bound on gap via Cheeger or conductance: \(\mathrm{gap}\ge \Phi^2/2\).  
- Log-Sobolev bound ⇒ hypercontractivity window.  
- Poincaré/log-Sobolev constants pre/post Q and under each closure.  
- Empirical coupling/OT distance decay consistent with TL1 Lipschitz.

---

## 4. Homotopy robustness (TL3)
If \(F:X\to Y\) is a Q-equivalence, \(\Q(F)\) is iso; then any spectral-gap certificate on \(X\) transports to \(Y\) and vice versa.  
Thus mixing guarantees are **invariants** in the Q-local homotopy category.

---

## 5. Practical recipe
1) Estimate \(\Phi\) or curvature to lower bound gap; compute \(\alpha_{LS}\) where possible.  
2) Apply \(\varsigma_s\) then \(\Q\); re-evaluate bounds—should be stable or improved.  
3) Emit **DMR-Gap** with: (i) bounds table, (ii) decay plots or formulas, (iii) TL1 distances before/after.

---

**Footer:**  
— KUSMAN Framework — Immediate Translation Layers v1.0
