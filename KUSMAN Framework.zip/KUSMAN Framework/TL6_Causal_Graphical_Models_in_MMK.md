# TL6 — Causal / Graphical Models inside \MMK (Bayes Nets, Do-Calculus, Sufficient Statistics)
**Version:** 1.0  
**Date:** 2025-10-09  
**Series:** KUSMAN Framework — Immediate Translation Layers

---

## 1. Embedding of DAG models
Let a Bayesian network \(\mathcal G=(V,E)\) with conditional probabilities \(\{P(X_v\mid X_{\mathrm{pa}(v)})\}\).
Define an \MMK object
\[
X_\mathcal G := (|X|, d, \mu, K)
\]
where \(|X|=\prod_{v\in V}\mathcal X_v\), \(\mu\) is the joint factorization, and \(K\) is a Gibbs/blocked transition kernel preserving \(\mu\).
The metric \(d\) is any product metric compatible with \(\mathcal X_v\).

**Functoriality.** A DAG homomorphism / variable renaming / marginalization induces a Markov coarse-graining \(F: X_\mathcal G\to X_{\mathcal G'}\).

---

## 2. Interventions (do-operator) as kernel surgery
For \(do(X_S = x_S)\), replace local conditionals on nodes \(S\) by deltas and renormalize parents/children; obtain \(X_{\mathcal G}^{do(S)}\in\MMK\).  
This is a **morphism in the slice**: \(X_{\mathcal G}^{do(S)}\to X_{\mathcal G}\) forgetting the intervention flag.

**Lemma TL6.1 (Markov blanket locality).** For any target \(T\), the effect of \(do(S)\) on observables measurable in \(T\) is mediated by the Markov blanket of \(T\) in \(\mathcal G\), hence a closure under \(\varsigma_\ell\) with respect to blanket predicates leaves effects invariant.

---

## 3. Closures as causal simplifications
- **\(\varsigma_a\)** (behavioral/minimization): merges nodes indistinguishable by all interventional distributions on \(T\).  
- **\(\varsigma_g\)** (geometric/recurrent): collapses transient causal pathways (instrumental variables with zero total effect).  
- **\(\varsigma_s\)** (spectral/slow): projects to slow mixing components (long causal memory).  
- **\(\varsigma_\ell\)** (logical): identifies variables indistinguishable by all causal queries \(P(Y\mid do(X))\).

**Theorem TL6.2 (Causal sufficiency via \Q).**  
Let \(\mathcal Q\) be a finite set of causal queries. There exists \(\Q_\mathcal Q(X_\mathcal G)\) such that for all \(q\in\mathcal Q\),  
\(q(X_\mathcal G)=q(\Q_\mathcal Q(X_\mathcal G))\) and \(\Q_\mathcal Q\) is minimal among \MMK objects with this property.

---

## 4. Identifiability as descent
Given observational model \(X_\mathcal G\) and an intervention cover \(\{do(S_i)\}\), **j_\ell-sheaf gluing** yields uniqueness of the effect \(P(Y\mid do(X))\) iff the Cech 1-cocycle on overlaps is trivial.

**Corollary TL6.3.** Back-door and front-door criteria correspond to acyclicity of the gluing nerve in the relevant cover site.

---

## 5. Information geometry
Define \(\mathcal R_{\text{causal}}\) measuring deviation of interventional marginals; \Q minimizes KL subject to preserving \(\mathcal Q\). Data-processing ⇒ monotonicity of estimation error under \Q.

---

## 6. Certificates (DMR-Causal)
- Query list \(\mathcal Q\) and exact preservation checks.  
- Blanket-based reductions witnessed.  
- KL decrease and Lipschitz radius.  

---

**Footer:**  
— KUSMAN Framework — Immediate Translation Layers v1.0
