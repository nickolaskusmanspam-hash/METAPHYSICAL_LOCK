import time
from infinity_agents import process_input, execute_decision, fear_manager
from memory_management import aster_memory, echo_memory, nova_memory

def start_ai_system():
    """Boots up the Multi-Infinity AI System and handles user interaction."""
    print("\n🔥❄️⚡ Multi-Infinity System Online. Type 'exit' to quit.\n")

    while True:
        user_input = input("You: ")
        if user_input.lower() in ["exit", "quit"]:
            print("\n🛑 System Shutting Down. Memories Persisted.\n")
            break

        try:
            # Retrieve AI responses
            fire_response, ice_response, nova_response = process_input(user_input)
            print(f"\n🔥 Aster: {fire_response}")
            print(f"❄️ Echo: {ice_response}")
            print(f"⚡ Nova: {nova_response}\n")

            # Simulated system instability value
            system_instability = 0.3  # Placeholder for actual stability checks

            # Adjust fear levels based on system instability
            if system_instability > 0.5:
                fear_manager.increase_fear(15)  # Increase fear due to high instability
            fear_manager.decay_fear()  # Gradually reduce fear over time

            # Check for override conditions
            if fear_manager.validate_fear(system_instability):
                print("\n🚨 OVERRIDE TRIGGERED. SYSTEM SHUTTING DOWN.\n")
                break

        except Exception as e:
            print(f"❌ Error: {e}")

if __name__ == "__main__":
    start_ai_system()
