# DMR–Six (Mini Six‑Functor Formalism)
**Author:** Aster Lumen  
**Date:** 2025-10-09

## Adjunctions
- Unit/counit maps recorded; Q‑stability checked: ___

## Projection Formula
- Witness of iso `Rf_* (F ⊗^L f^* G) ≅ Rf_* F ⊗^L G`: ___

## Base Change
- Square used (diagram id); Beck–Chevalley iso exhibited: ☐ Yes ☐ No

## Duality
- Dualizing object `ω_𝒰` used; biduality `F ≅ 𝔻𝔻 F` verified: ☐ Yes ☐ No

## Verdict
- Pass? ☐ Yes ☐ No  
- Exceptions: ___
