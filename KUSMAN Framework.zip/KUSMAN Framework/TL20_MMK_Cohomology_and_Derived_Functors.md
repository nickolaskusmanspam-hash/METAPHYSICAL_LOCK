# TL20 — MMK Cohomology & Derived Functors (Čech ↔ Sheaf; Mini Six‑Functor Core)
**Author:** Aster Lumen  
**Date:** 2025-10-09  
**Series:** KUSMAN Framework — Cohomology Tightening

---

## Objective
Define cohomology for \MMK sites, show **Čech = derived sheaf** under acyclicity, and assemble a **mini six‑functor** formalism stable under the aggregator `Q` and Ϙ–ς closures.

---

## 1. Site and coefficients
Work on a TL2 boundary/interface site `𝒰` (or a diffusion site) with `j`‑covers. A **coefficient sheaf** `𝓕` is an abelian sheaf on `𝒰` valued in Banach/Fréchet spaces that is **Q‑stable** (restriction maps commute with `Q`).

---

## 2. Čech cohomology
For a cover `U = ⋃_i U_i`, define the Čech complex `Ĉ^•(𝒰,𝓕)` with
`Ĉ^p = ∏_{i_0<⋯<i_p} 𝓕(U_{i_0…i_p})` and alternating coboundary. The **Q‑stabilized** complex uses `𝓕^Q := im(𝓕 → Q∘𝓕)`; write `Ĉ^•_Q`.

**Lemma 20.1 (Mayer–Vietoris via equalizers).** For a two‑set cover, `H^•` is computed by the equalizer diagram used in TL10b; compatibility with DN/ND boundary functors gives natural long exact sequences.

---

## 3. Derived sheaf cohomology
Let `Sh(𝒰)` denote sheaves on the site. Use injective (or soft/fine) resolutions `𝓕→𝓘^•` with `Q`‑compatibility. Define `RΓ(𝒰,𝓕)` as the derived global‑sections functor.

**Theorem 20.2 (Čech = derived under acyclicity).** If the cover is `𝓕`‑acyclic (all finite intersections have vanishing higher cohomology), then `H^p_{Čech}(𝒰,𝓕) ≅ H^p(𝒰,𝓕)` naturally; same for `Q`‑stabilized coefficients.

---

## 4. Mini six‑functor core
For a map of sites `f: 𝒰→𝒱` (e.g., inclusion/refinement):
- `f^*` (inverse image) preserves `Q`‑stability and commutes with ϛₓ.  
- `f_*` (direct image) right adjoint to `f^*`; derived `Rf_*` preserves long exact sequences.  
- For open embeddings, define `f_!` (extension by zero) and its right adjoint `f^!` on `Q`‑stable coefficients.  
- Tensor `⊗` and `RHom` on coefficient complexes, with `Q` acting as a lax monoidal endofunctor.

**Theorem 20.3 (Q‑stability of cohomology).** If `Q` is exact on the coefficient category (true for the stabilized subcategory) and preserves acyclic resolutions, then `Q` commutes with `RΓ` up to iso: `Q(H^p) ≅ H^p(Q(−))`.

---

## 5. Spectral sequences & descent
- **Leray spectral sequence:** `E_2^{p,q} = H^p(𝒱, R^q f_* 𝓕) ⇒ H^{p+q}(𝒰, 𝓕)` in the Q‑stable regime.  
- **Descent:** For a hypercover by `j`‑covers, cohomology is computed by the associated total complex; `Q` respects the filtration and degenerations.

---

## 6. Certificates — DMR–Coh
- Site & cover specification; acyclicity checks on intersections  
- Q‑stability of coefficient sheaf  
- Čech/derived comparison witness and, if used, a Leray SS page snapshot  
- Functor operations used (f^*, f_*, f_!, f^!, ⊗, RHom) and exactness notes

**Footer:** — KUSMAN Cohomology Tightening v1.0
