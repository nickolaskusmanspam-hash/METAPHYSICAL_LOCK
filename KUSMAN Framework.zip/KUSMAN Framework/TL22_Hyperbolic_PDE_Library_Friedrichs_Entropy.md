# TL22 — Hyperbolic PDE Library in \MMK (Friedrichs Symmetrization + Entropy Pairs)
**Author:** Aster Lumen  
**Date:** 2025-10-09  
**Series:** KUSMAN Framework — PDE Tightening

---

## Objective
Extend TL16 by (i) constructing **Friedrichs symmetrizers** for first‑order systems; (ii) developing **entropy/entropy‑flux pairs** for conservation laws, including relative entropy; and (iii) integrating these with boundary/interface sheaves (TL10b) and closures.

---

## 1. First‑order systems and Friedrichs symmetrization
System: \(\partial_t U + \sum_{i=1}^d A^i(U,x)\,\partial_{x_i} U = S(U,x)\).

**Definition 22.1 (Friedrichs symmetrizer).** A positive definite matrix \(H(U,x)\) such that each \(H A^i\) is symmetric.  
**Existence (linear case).** If the symbol \(\sum \xi_i A^i\) is diagonalizable with real spectrum uniformly in \(\xi\ne 0\), a smooth symmetrizer exists (Kreiss).  
**Energy.** \(E[U]=\int_\Omega \langle U, H(U) U\rangle\,dx\) obeys a balance law with boundary flux resolved by maximally dissipative BCs.

---

## 2. Conservation laws and entropy pairs
Conservation law: \(\partial_t U + \nabla\cdot F(U)=0\).

**Definition 22.2 (Entropy pair).** A convex \(\eta: \mathbb R^m\to\mathbb R\) with flux \(q\) s.t. \(\nabla\eta(U)\,\nabla F(U) = \nabla q(U)\).  
Entropy solutions satisfy \(\partial_t \eta(U)+\nabla\cdot q(U) \le 0\) in distributions.

**Relative entropy.** For a reference state/solution \(V\), define \(\eta(U\mid V)=\eta(U)-\eta(V)-\nabla\eta(V)\cdot (U-V)\). Yields stability and weak–strong uniqueness estimates.

---

## 3. Interfaces, shocks, and stability
- **Rankine–Hugoniot.** Across an interface \(\Gamma(t)\) with normal \(n\): \([F(U)\cdot n] = s\,[U]\).  
- **Lopatinski condition.** Ensures well‑posedness of boundary/shock problems.  
- **BV/Glimm sketch (1D).** Interaction potential controls total variation; entropy enforces admissibility.

---

## 4. MMK integration
- Map states to \MMK via energy/Fisher metrics (TL1); semigroup kernels from time stepping.  
- **Closures.** Spectral closure \(\varsigma_s\) removes fast/ill‑posed modes; automaton closure \(\varsigma_a\) canonicalizes Riemann solvers; geometric closure \(\varsigma_g\) merges transient cells.  
- **Aggregator Q.** Contracts energy and preserves admissible shocks when entropy is convex, yielding monotone decay of relative entropy.

**Theorem 22.3 (Relative entropy decay under Q).** For entropy solutions with convex \(\eta\) and compatible BCs, \(t\mapsto \int \eta(U\mid V)\,dx\) is non‑increasing after applying \(\varsigma_s\) and \(Q\); interfaces glued by TL10b maintain the inequality.

---

## 5. Numerical schemes and entropy stability (brief)
- **CFL stability** and **entropy‑stable fluxes** (Tadmor): discrete entropy inequality \(\eta(U^{n+1})\le \eta(U^{n})\) up to sources.  
- Q‑compatibility: coarse‑graining commutes with flux limiting; discrete relative entropy decreases.

---

## 6. Certificates — DMR–Hyp v2
- Symmetrizer construction (Friedrichs) and bounds  
- Entropy/flux pair list; convexity checks; relative‑entropy Lyapunov  
- Lopatinski verification for interfaces/shocks  
- Q/closure monotonicity (energy and entropy) with plots/tables hooks

**Footer:** — KUSMAN PDE Tightening v1.0
