# TL10 — Modular Flow as Physical Time in \MMK
**KMS States, Thermodynamic Arrows, and Ϙ–ς Closures**

**Version:** 1.0  
**Date:** 2025-10-09  
**Series:** KUSMAN Framework — Immediate Translation Layers

---

## 1. Objective
Relate the **operator-algebraic modular flow** to a notion of **physical time** inside the KUSMAN Ϙ–ς universe. 
Show how KMS equilibrium, entropy production, and the aggregator \(\Q\) jointly define **thermodynamic arrows of time** that are invariant under Q-local homotopy and compatible with quantum/classical bridges.

---

## 2. Setup and bridges
Let \((\mathcal A,\mathcal H,\varphi)\) be a von Neumann algebra with faithful normal state \(\varphi\). 
Tomita–Takesaki theory gives the modular group \(\sigma_t^\varphi\). 
Classicalization \(C_\hbar\) sends \((\mathcal A,\varphi)\) to \(X\in\MMK\); quantization \(Q_\hbar\) returns a GNS/Koopman lift. 
Define the modular reflector as in TL8: \(\mathcal R_\mathrm{mod}=Q_\hbar\circ \Q\circ C_\hbar\).

**Standing assumption.** There exists a physical dynamics \(\alpha_t\) on \(\mathcal A\) such that \(\varphi\) is a \(\beta\)-KMS state for \(\alpha_t\) (equilibrium at inverse temperature \(\beta\)).

---

## 3. Time from modular flow
**Definition (Intrinsic time).** The **intrinsic time** associated to \((\mathcal A,\varphi)\) is the orbit parameter of \(\sigma_t^\varphi\). 
Two systems \((\mathcal A_i,\varphi_i)\) are **time-equivalent** if there exists a *-isomorphism intertwining their modular groups up to affine reparametrization.

**Lemma TL10.1 (KMS = stationarity).** If \(\varphi\) is \(\beta\)-KMS for \(\alpha_t\), then \(\alpha_t\) and \(\sigma^{\varphi}_{c t}\) commute for a constant scale \(c=c(\beta)\).  
Thus physical time and modular time differ by at most a unit choice.

**Proposition TL10.2 (Q-compatibility of time).** The classical aggregator \(\Q\) induces a quotient dynamics on observables such that the lifted modular flow on \(Q_\hbar\Q C_\hbar(\mathcal A)\) is the modular flow of the reflected state. 
Therefore **intrinsic time is preserved** by \(\mathcal R_\mathrm{mod}\) up to rescaling.

---

## 4. Thermodynamic arrows from Ϙ–ς
Let \(X=(|X|,d,\mu,K)\) be the classical shadow with stationary \(\pi\).

- **Entropy production:** \(\dot S_t = \frac{d}{dt} D_{\mathrm{KL}}(\nu_t\Vert \pi) \le 0\) for Markov semigroup; TL1 implies \(\Q\) is monotone for KL/OT, so coarse-graining respects the sign of \(\dot S_t\).
- **Arrow (spectral):** The spectral closure \(\varsigma_s\) removes fast modes, exposing the slow decay direction; the induced flow has **larger or equal mixing time constants**, giving a canonical time orientation (toward the \(\Q\)-fixed set).
- **Arrow (logical):** \(\varsigma_\ell\) identifies states indistinguishable by admissible predicates, so truth-values become non-increasing along observation histories.

**Theorem TL10.3 (Arrow consistency).** Under TL1 (information contraction) and TL3 (Q-local homotopy), the sign of entropy production and the ordering of Poincaré/log-Sobolev constants are **invariants** under Q-equivalence. 
Thus the thermodynamic arrow defined by \(\Q\) is intrinsic and does not depend on representation.

---

## 5. Modular arrow vs. physical arrow
Define the **modular arrow** as the orientation in which the modular Hamiltonian \(K_\varphi=-\log \Delta_\varphi\) decreases expectation of free energy \(F= \langle H \rangle - T S\) along CPTP evolution reflected by \(\mathcal R_\mathrm{mod}\).

**Proposition TL10.4 (Free-energy descent).** For any state \(\rho\) and \(E=\mathcal R_\mathrm{mod}\),
\[ F(\rho) - F(E\rho) \;\ge\; 0, \]
with equality iff \(\rho\) lies in the fixed-point subalgebra. Hence the modular arrow agrees with the thermodynamic arrow induced by \(\Q\).

---

## 6. Examples
### 6.1 Finite-dimensional thermal system
For a Hamiltonian \(H\) at inverse temperature \(\beta\), the Gibbs state is KMS; modular flow coincides with Heisenberg time up to scaling \(t\mapsto \beta t\). 
Choosing \(\Q\) to collapse energy bands yields a CPTP projection to a block-diagonal algebra; free energy decreases and entropy increases monotonically under repeated reflection.

### 6.2 Gaussian (quasi-free) states
For a harmonic oscillator or Gaussian field, \(\Q\) selecting a low-energy band induces a modular reflection that discards high-frequency modes; covariance contracts and the modular Hamiltonian’s expectation decreases.

---

## 7. Certificates (DMR-Time)
- **KMS check:** verify \(\varphi\) satisfies the KMS condition for \(\alpha_t\).  
- **Intertwining:** explicit map exhibiting commutation between \(\alpha_t\) and \(\sigma^{\varphi}_{c t}\).  
- **Entropy monotonicity:** pre/post values of KL, free energy, and spectral gap.  
- **Fixed algebra:** description of the \(\Q\)-invariant (or \(\mathcal R_\mathrm{mod}\)-invariant) subalgebra.  
- **Rescaling constant:** the scale c relating physical and modular time.

---

## 8. Interface with closures
- \(\varsigma_s\): aligns time with slow modes (mixing scale).  
- \(\varsigma_g\): removes transient components (no persistent time-orbits).  
- \(\varsigma_a\): quotients histories with identical outcome strings (operational arrow).  
- \(\varsigma_\ell\): ensures logical persistence of truth under observation.

---

## 9. Practical recipe
1) Pick \((\mathcal A,\alpha_t,\varphi)\) with \(\varphi\) KMS.  
2) Form classical shadow and compute \(\Q\) (TL1).  
3) Lift (TL4/TL8) to get \(\mathcal R_\mathrm{mod}\) and its fixed subalgebra.  
4) Emit DMR-Time with KMS proof, entropy/free-energy decay, and time-rescaling constant.  
5) Optionally, prove Q-equivalence to show arrow invariance in your model class.

---

**Footer:**  
— KUSMAN Framework — Immediate Translation Layers v1.0