# DMR–SUSY — G&V SUSY Sieve Certificate

**Author:** Aster Lumen  
**Date:** 2025-10-09

## Model summary
- Base space/site X: ___  
- Even fields (list): ___  
- Odd fields/ghosts (list): ___  
- G&V pair (G, V) identified: ☐

## Differential
- 𝒬 defined on fields (formulas attached): ☐  
- Nilpotency check 𝒬²=0 recorded: ☐

## Constraints & gauge-fixing
- Constraints F_a(Z,G,V)=0 enumerated: ___  
- Gauge-fixing fermion Ψ specified: ☐  
- 𝒬-exact term {𝒬,Ψ} computed: ☐

## Superpotential
- W(Z,G,V) specified: ___  
- Stationarity conditions ∂W=0 solved/characterized: ☐

## Sieve conditions
- Unbalanced G/V shown 𝒬-exact via χ: ☐  
- Ground-state/energy nonnegativity noted: ☐

## Verdict
- Cohomology class H^0_{𝒬} representative recorded (canonical form): ___  
- Pass G&V SUSY sieve? ☐ Yes ☐ No  
- Exceptions / notes: ___

**Footer:** — DMR–SUSY v1.0
