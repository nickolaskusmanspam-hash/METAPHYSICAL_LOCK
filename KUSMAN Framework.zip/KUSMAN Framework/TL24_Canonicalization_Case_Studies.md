# TL24 — Canonicalization Case Studies in \MMK (Graphs, DFA, Matrices)
**Author:** Aster Lumen  
**Date:** 2025-10-09  
**Series:** KUSMAN Complexity Tightening — Canonicalization

---

## Objective
Demonstrate **polytime canonicalization** (where available) or tightly controlled pipelines inside \MMK for three domains:
1) **Graphs up to isomorphism** (spectral + partition refinement),  
2) **DFA minimization** (Myhill–Nerode / bisimulation via ϛ_a),  
3) **Matrix normal forms** (Smith / Frobenius).  

Each case includes an **MMK presentation**, a **closure-driven canonicalization** (ϛ_a, ϛ_s, ϛ_g, j_ℓ), and a **DMR–Comp v2** checklist.

---

## 1) Graph Isomorphism (GI) — Spectral + Refinement
**MMK object.** A finite graph `G=(V,E)` becomes `X_G=(V,d,μ,K)` where `K` is the lazy random walk (row-stochastic), `μ` uniform, and `d` the commute-time or resistance metric.

**Closures.**  
- `ϛ_s` (spectral): project to leading eigenmodes of `K`/`A`; yields stable coordinates `Φ(v)` (eigenmaps).  
- `ϛ_a` (automaton/partition): equitable partition refinement (color-refinement/Weisfeiler–Leman-1).  
- `ϛ_g` (geometric): merge near-degenerate spectral classes to stabilize numerics.

**Canonicalization.**  
(i) Run refinement to a stable partition `P`.  
(ii) Within each cell, order vertices by lexicographic spectral signature from `ϛ_s`.  
(iii) Produce a **canonical labeling** `σ: V→{1..n}`.

**Complexity.** WL-1 is near-linear in `m log n`; spectral step is polytime. Full GI is not known polytime in general, but this pipeline produces a robust **canonical form** for large practical families (esp. regular/random-like graphs).  

**DMR–Comp v2 (graph)**: record WL stabilization steps, spectral tolerance, and Lipschitz constants from TL1.

---

## 2) DFA Minimization — Myhill–Nerode via ϛ_a
**MMK object.** States `Q`, alphabet `Σ`, kernel `K((q,a),q')` is deterministic (mass on `δ(q,a)`); measure the counting law; metric `d` as hitting-time or language-equivalence distance.

**Closure.** `ϛ_a` computes the coarsest **bisimulation/equivalence** compatible with acceptance; this is classical DFA minimization.

**Canonicalization.** Order minimized states by shortlex of distinguishing words (or by stable topological order of the DFA graph) to obtain a canonical presentation.  
**Complexity.** Hopcroft’s minimization is `O(|Σ| n log n)`; canonical ordering adds at most `O(n log n)`.

**DMR–Comp v2 (DFA)**: record partition blocks, witness lengths, and verification costs.

---

## 3) Matrices — Smith & Frobenius Normal Forms
**Domains.**  
- **Smith Normal Form (SNF)** for integer matrices: `U A V = diag(d_1,…,d_r,0,…)` with `d_i | d_{i+1}`.  
- **Frobenius (rational canonical) form** over a field: `A ≅ diag(C(p_1),…,C(p_k))` with companion matrices for invariant factors.

**MMK object.** View rows/cols as nodes; kernels arise from linear maps under random probing; TL1 metric induced by operator norm.

**Closures.**  
- `ϛ_s`: spectral thresholds / invariant factor stabilization,  
- `ϛ_a`: canonical companion-block formation,  
- `ϛ_g`: merge nearly collinear subspaces.

**Canonicalization.** SNF and Frobenius forms are canonical (up to block order); we fix the lexicographic order of invariant factors for uniqueness.

**Complexity.** SNF/Frobenius can be computed in polynomial time using modular methods; record bounds under the chosen ring/field.

**DMR–Comp v2 (matrix)**: record ring/field, invariant factors, and modular lifting bounds.

---

## DMR–Comp v2 — Unified Checklist
- **Size/Cost model** specified (input encoding, |·|).  
- **Canonicalization** existence & complexity recorded (poly/qp).  
- **Reduction stability:** Lipschitz constants in TL1 metrics.  
- **Verification:** succinct witness for equality of canonical forms.  

**Footer:** — KUSMAN Complexity Tightening — TL24 v1.0
