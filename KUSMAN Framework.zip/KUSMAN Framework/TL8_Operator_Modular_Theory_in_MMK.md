# TL8 — Operator-Algebraic Modular Theory in \MMK
**Tomita–Takesaki as a Q-Reflector; KMS, Conditional Expectations, and Decoherence**

**Version:** 1.0  
**Date:** 2025-10-09  
**Series:** KUSMAN Framework — Immediate Translation Layers

---

## 1. Objects and bridges
- Let \(\mathcal{A}\) be a (possibly von Neumann) algebra of observables acting on a Hilbert space \(\mathcal H\).  
- Fix a faithful normal state \(\varphi\) (GNS vector \(|\Omega_\varphi\rangle\)).  
- Tomita operator: \(S_\varphi A|\Omega_\varphi\rangle = A^*|\Omega_\varphi\rangle\). Polar decomposition \(S_\varphi = J_\varphi\Delta_\varphi^{1/2}\).  
- **Modular automorphisms:** \(\sigma_t^\varphi(A) = \Delta_\varphi^{it} A \Delta_\varphi^{-it}\).

**Classicalization/Quantization functors:** as in TL4, \(C_\hbar: (\mathcal H,U)\mapsto X\in\MMK\), \(Q_\hbar: X\mapsto (\mathcal H_X,\mathsf U_X)\).  
We enrich \(Q_\hbar\) to carry modular data: when \(X\) bears a stationary measure \(\mu\), the Koopman/GNS lift induces a cyclic separating vector, hence a modular pair \((J,\Delta)\).

---

## 2. Modular reflection as a Q-reflector
Consider the classical aggregator \(\Q: \MMK\to\MMK\). Define the **quantum modular reflector**
\[
\mathcal R_\mathrm{mod} := Q_\hbar\,\circ\,\Q\,\circ\,C_\hbar : (\mathcal H,\mathcal A,\varphi)\longrightarrow(\mathcal H,\mathcal A,\varphi).
\]
**Theorem TL8.1 (Conditional expectation).** There exists a von Neumann subalgebra \(\mathcal N\subseteq\mathcal A\) such that \(\mathcal R_\mathrm{mod}|_{\mathcal A}=E_{\mathcal N}:\mathcal A\to\mathcal N\) is the unique \(\varphi\)-preserving conditional expectation with
\(E_{\mathcal N}\circ E_{\mathcal N}=E_{\mathcal N}\), \(E_{\mathcal N}=E_{\mathcal N}^*\), and \(\sigma_t^\varphi(\mathcal N)=\mathcal N\) for all \(t\).  
*Meaning:* \(\Q\) on the classical shadow corresponds to **modularly invariant decoherence** onto \(\mathcal N\).

**Corollary TL8.2 (KMS compatibility).** If \(\varphi\) is a \(\beta\)-KMS state for a dynamics \(\alpha_t\) (quantum time evolution), then \(\mathcal N\) is globally \(\alpha_t\)-invariant and \(\varphi\circ E_{\mathcal N}=\varphi\).  Thus \(\mathcal R_\mathrm{mod}\) preserves thermal equilibrium.

---

## 3. Modular certificates (DMR-Mod)
- **Fixed subalgebra:** explicit generators of \(\mathcal N\).  
- **Kraus/CE form:** representation of \(E_{\mathcal N}\) (finite or approximate).  
- **Entropy drop:** \(S(\rho\Vert\sigma)\ge S(E\rho\Vert E\sigma)\).  
- **Modular invariance:** check \(\sigma_t^\varphi(\mathcal N)=\mathcal N\).  
- **KMS check:** for thermal states, verify \(\varphi(A\alpha_{i\beta}(B))=\varphi(BA)\) remains valid post-reflection.

---

## 4. Relation to closures and HoTT modalities
- **Logical closure \(\varsigma_\ell\):** indistinguishability by \(\varphi\)-expectations \(\Rightarrow\) collapse to center of \(\mathcal N\).  
- **Spectral closure \(\varsigma_s\):** projects away fast modular phases (high spectral values of \(\Delta\)).  
- **Geometric \(\varsigma_g\):** merges transient subspaces (no persistent modular orbits).  
- **Automaton \(\varsigma_a\):** merges states with identical outcome histories under sequences of effects.

---

## 5. Practical recipe
1) Build classical shadow \(X=C_\hbar(\mathcal H,\mathcal A,\varphi)\).  
2) Compute \(\Q(X)\) (TL1 metrics).  
3) Lift back with \(Q_\hbar\) and identify \(\mathcal N\) s.t. \(\mathcal R_\mathrm{mod}=E_{\mathcal N}\).  
4) Emit DMR-Mod cert; export Kraus/expectation form for reuse.

---

**Footer:**  
— KUSMAN Framework — Immediate Translation Layers v1.0
