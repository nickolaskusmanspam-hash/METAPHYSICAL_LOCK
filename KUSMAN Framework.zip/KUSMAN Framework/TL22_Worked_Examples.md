# TL22 — Worked Examples: Linear Acoustics & Compressible Euler (Ϙ–ς)

**Author:** Aster Lumen  
**Date:** 2025-10-09  
**Series:** KUSMAN PDE Tightening — Worked Examples

---

## A. Linear Acoustics (1D)

Small perturbations around a uniform state `(ρ0, u0=0, p0)` with sound speed `c^2 = (∂p/∂ρ)|_{ρ0}`:
\[
\partial_t \rho' + \rho_0\, \partial_x u' = 0,\qquad
\partial_t u' + \frac{c^2}{\rho_0}\, \partial_x \rho' = 0.
\]

Vector form `U=(ρ', u')^T` with constant matrix
\[
A = \begin{pmatrix} 0 & \rho_0 \\ c^2/\rho_0 & 0 \end{pmatrix}.
\]

### Symmetrizer (Friedrichs)
Choose
\[
H = \mathrm{diag}\left(\frac{c^2}{\rho_0^2},\; 1\right).
\]
Then `H A` is symmetric and the **energy**
\[
E[U] = \tfrac12 \int_{\Omega} \left( \tfrac{c^2}{\rho_0^2} (\rho')^2 + (u')^2 \right) dx
\]
satisfies the standard balance with a maximally dissipative boundary form.

### Entropy pair
Define entropy \(\eta(U)=E\) and entropy flux \(q(U)= \tfrac{c^2}{\rho_0}\, \rho' u'\).  
Relative entropy against a reference \(V=(\tilde\rho',\tilde u')\):
\[
\eta(U\mid V)= \tfrac12\left[ \tfrac{c^2}{\rho_0^2}(\rho'-\tilde\rho')^2 + (u'-\tilde u')^2\right].
\]

---

## B. Compressible Euler (Isentropic, 1D)

Unknowns `ρ>0`, `u` with pressure law `p(ρ)` (e.g., polytropic `p(ρ)=κ ρ^γ`, `γ>1`):
\[
\partial_t \rho + \partial_x(\rho u) = 0,\qquad
\partial_t (\rho u) + \partial_x(\rho u^2 + p(\rho)) = 0.
\]
Let `U=(ρ, m)^T` with `m=ρ u` and flux `F(U)=(m, m^2/ρ + p(ρ))^T`.

### Symmetrizer (standard)
In variables `(ρ,u)` a **symmetric-hyperbolic** form is obtained with
\[
H(\rho) = \mathrm{diag}\!\left( \frac{p'(\rho)}{\rho},\; \rho \right),\quad
c^2(\rho)=p'(\rho).
\]
Then the energy density `⟨U, H U⟩` is comparable to `\eta` below near smooth states.

### Convex entropy & flux
Let specific internal energy `e(ρ)` satisfy `e'(ρ) = p(ρ)/ρ^2`. Define the convex entropy
\[
\eta(\rho,u) = \tfrac12 \rho u^2 + e(\rho),\qquad
q(\rho,u) = u\,\big( \tfrac12 \rho u^2 + h(\rho)\big),\quad
h(\rho)=e(\rho)+\tfrac{p(\rho)}{\rho}.
\]
For a polytrope `p(ρ)=κ ρ^γ`, one has `e(ρ)=\tfrac{\kappa}{\gamma-1} \rho^{\gamma-1}` and `h(ρ)=\tfrac{\gamma \kappa}{\gamma-1} \rho^{\gamma-1}`.

### Relative entropy (weak–strong stability)
For a reference solution `(σ,v)`, the relative entropy is
\[
\eta\big((\rho,u)\mid(\sigma,v)\big) =
\tfrac12 \rho (u-v)^2 + e(\rho) - e(\sigma) - e'(\sigma) (\rho-\sigma).
\]
Under admissible boundary/interface conditions (TL10b) and convex `\eta`, the integral of `\eta(\cdot\mid\cdot)` is non‑increasing after spectral closure `ϛ_s` and aggregation `Q` (TL22 Theorem 22.3).

---

## C. Entropy Pair Table (common choices)

| System | Variables | Entropy `η` | Flux `q` | Notes |
|---|---|---|---|---|
| Linear acoustics | `(ρ', u')` | `1/2[(c^2/ρ_0^2)(ρ')^2 + (u')^2]` | `(c^2/ρ_0) ρ' u'` | Symmetrizer `H=diag(c^2/ρ_0^2, 1)` |
| Isentropic Euler (polytropic) | `(ρ, u)` | `1/2 ρ u^2 + κ/(γ−1) ρ^{γ−1}` | `u(1/2 ρ u^2 + γ κ/(γ−1) ρ^{γ−1})` | `c^2=γ κ ρ^{γ−1}` |

**Interface notes.** Across shocks/interfaces, impose Rankine–Hugoniot and entropy inequality; the TL10b equalizer glues subdomain solutions with DN/ND boundary functors.

**Footer:** — KUSMAN PDE Tightening — TL22 Worked Examples v1.0
