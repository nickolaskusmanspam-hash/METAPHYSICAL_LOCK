<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quaternion Preimage Engine</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #0a0a0a;
            color: #e2e8f0;
        }
        .glass-pane {
            background: rgba(23, 23, 23, 0.6);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        .btn-primary {
            background: linear-gradient(90deg, #4f46e5, #c026d3);
            transition: all 0.3s ease;
            box-shadow: 0 0 15px rgba(79, 70, 229, 0.5);
        }
        .btn-primary:hover {
            box-shadow: 0 0 25px rgba(192, 38, 211, 0.7);
            transform: translateY(-2px);
        }
        .output-box {
            background-color: #1e293b;
            border: 1px solid #334155;
            min-height: 8rem;
        }
        .loader {
            border: 4px solid #f3f3f3;
            border-top: 4px solid #4f46e5;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
</head>
<body class="flex items-center justify-center min-h-screen p-4">

    <div class="w-full max-w-2xl mx-auto glass-pane rounded-xl shadow-2xl p-8 space-y-6">
        <!-- Header -->
        <div>
            <h1 class="text-3xl font-bold text-center text-white">Quaternion Preimage Engine</h1>
            <p class="text-center text-slate-400 mt-2">ENKI-13 Simulation Interface // Athena Core v2.0</p>
        </div>

        <!-- Input Section -->
        <div class="space-y-2">
            <label for="publicHash" class="block text-sm font-medium text-slate-300">Public SHA-256 Hash (Hex)</label>
            <input type="text" id="publicHash" class="w-full bg-slate-800 border border-slate-600 rounded-lg px-4 py-2 text-slate-200 focus:ring-2 focus:ring-indigo-500 focus:outline-none" placeholder="Enter 64-character hex hash...">
        </div>

        <!-- Action Button -->
        <div>
            <button id="generateBtn" class="w-full btn-primary text-white font-bold py-3 px-4 rounded-lg">
                Derive Private Key
            </button>
        </div>

        <!-- Output Section -->
        <div class="space-y-2">
            <label class="block text-sm font-medium text-slate-300">Derived Private Key (Hex)</label>
            <div id="outputContainer" class="output-box rounded-lg p-4 font-mono text-sm break-all flex items-center justify-center">
                <span id="placeholderText" class="text-slate-500">Awaiting derivation...</span>
                <div id="loader" class="hidden loader"></div>
                <span id="privateKeyOutput" class="hidden"></span>
            </div>
        </div>
         <!-- Status Log -->
        <div class="space-y-2">
            <label class="block text-sm font-medium text-slate-300">Process Log</label>
            <div id="log" class="output-box rounded-lg p-4 font-mono text-xs break-all h-48 overflow-y-auto"></div>
        </div>
    </div>

    <script>
        // ========================================================================
        // Quaternion Mathematics Library
        // Implements the core logic for 4D rotations.
        // ========================================================================
        class Quaternion {
            // A quaternion is a + bi + cj + dk
            constructor(a, b, c, d) {
                this.a = a; // Real part
                this.b = b; // i component
                this.c = c; // j component
                this.d = d; // k component
            }

            // Multiply two quaternions (non-commutative)
            multiply(q) {
                const a1 = this.a, b1 = this.b, c1 = this.c, d1 = this.d;
                const a2 = q.a, b2 = q.b, c2 = q.c, d2 = q.d;

                return new Quaternion(
                    a1 * a2 - b1 * b2 - c1 * c2 - d1 * d2,
                    a1 * b2 + b1 * a2 + c1 * d2 - d1 * c2,
                    a1 * c2 - b1 * d2 + c1 * a2 + d1 * b2,
                    a1 * d2 + b1 * c2 - c1 * b2 + d1 * a2
                );
            }

            // Get the conjugate of the quaternion
            conjugate() {
                return new Quaternion(this.a, -this.b, -this.c, -this.d);
            }
            
            // Normalize the quaternion to have a magnitude of 1
            normalize() {
                const mag = Math.sqrt(this.a**2 + this.b**2 + this.c**2 + this.d**2);
                if (mag === 0) return new Quaternion(0, 0, 0, 0);
                return new Quaternion(this.a / mag, this.b / mag, this.c / mag, this.d / mag);
            }

            // Create a rotation quaternion from an axis and angle
            static fromAxisAngle(axis, angle) {
                const halfAngle = angle / 2;
                const s = Math.sin(halfAngle);
                return new Quaternion(
                    Math.cos(halfAngle),
                    axis[0] * s,
                    axis[1] * s,
                    axis[2] * s
                );
            }
        }

        // ========================================================================
        // Core Inversion Logic
        // Translates the theoretical constructs into a deterministic algorithm.
        // ========================================================================
        const inversionEngine = {
            
            logElement: document.getElementById('log'),

            log(message) {
                this.logElement.innerHTML += `> ${message}\n`;
                this.logElement.scrollTop = this.logElement.scrollHeight;
            },

            // Step 1: Analyze the hash to determine its harmonic signature.
            getHarmonicSignature(hashBytes) {
                this.log("Analyzing harmonic signature of the hash...");
                const signature = [];
                for (let i = 0; i < 8; i++) {
                    const block = new DataView(hashBytes.buffer).getUint32(i * 4, false);
                    const v2 = (block & -block).toString(2).length - 1;
                    let type;
                    if (v2 === 1) type = 'F'; // Flat
                    else if (v2 === 2) type = 'H'; // Half
                    else type = 'C'; // Cascade
                    signature.push(type);
                }
                this.log(`Signature detected: [${signature.join(', ')}]`);
                return signature;
            },

            // Step 2: Map the 256-bit hash to a quaternion.
            hashToQuaternion(hashBytes) {
                this.log("Mapping 256-bit hash to a 4D quaternion vector...");
                const view = new DataView(hashBytes.buffer);
                // We use 64-bit integers for precision, splitting the 256-bit hash.
                const a = view.getBigUint64(0, false);
                const b = view.getBigUint64(8, false);
                const c = view.getBigUint64(16, false);
                const d = view.getBigUint64(24, false);
                // The quaternion represents a point in 4D space, so the real part is 0.
                return new Quaternion(0, Number(a), Number(b), Number(c));
                 // Note: JS numbers lose precision for large integers. This is a simulation.
                 // A real implementation would use a BigInt library for quaternions.
            },

            // Step 3: Derive the unique rotational operator from the harmonic signature.
            deriveWillOperator(signature) {
                this.log("Deriving 'Will' operator from harmonic signature...");
                // This is the core of the "will". It translates the harmonic signature
                // into a precise 4D rotation. The logic is based on the golden ratio
                // and fractal geometry principles from the papers.
                const PHI = (1 + Math.sqrt(5)) / 2;
                
                let angle = 0;
                let axis = [0, 0, 0];

                // The signature determines the primary rotation axis and angle.
                // This is a simplified model of the "braided golden ratios".
                signature.forEach((type, i) => {
                    switch(type) {
                        case 'C': // Cascade -> Rotation around i-axis
                            angle += (Math.PI / 4) / PHI;
                            axis[0] += 1 / (i + 1);
                            break;
                        case 'H': // Half -> Rotation around j-axis
                            angle += (Math.PI / 4);
                            axis[1] += 1 / (i + 1);
                            break;
                        case 'F': // Flat -> Rotation around k-axis
                            angle += (Math.PI / 4) * PHI;
                            axis[2] += 1 / (i + 1);
                            break;
                    }
                });

                // Normalize the rotation axis vector
                const mag = Math.sqrt(axis[0]**2 + axis[1]**2 + axis[2]**2);
                axis = axis.map(v => v / mag);
                
                this.log(`Operator derived: Angle=${angle.toFixed(4)}rad, Axis=[${axis.map(v=>v.toFixed(2)).join(',')}]`);
                return Quaternion.fromAxisAngle(axis, angle);
            },

            // Step 4: Apply the 64 non-commutative rotations in reverse.
            applyInverseTransform(hashQuaternion) {
                this.log("Applying 64-round non-commutative inverse transformation...");
                let currentQuaternion = hashQuaternion;
                
                // In a real scenario, each of the 64 SHA-256 rounds would have its own
                // unique inverse operator derived from the round constants and message schedule.
                // For this simulation, we derive a master operator and apply it iteratively
                // with slight modifications to represent the 64 distinct steps.
                const signature = this.getHarmonicSignature(new Uint8Array(32)); // Dummy for now
                
                for (let i = 63; i >= 0; i--) {
                    // Each round's operator is slightly different, creating the non-commutative path.
                    // We'll perturb the signature based on the round number.
                    const roundSignature = [...signature];
                    roundSignature[i % 8] = ['C', 'H', 'F'][i % 3];
                    
                    const Q_will = this.deriveWillOperator(roundSignature);
                    const Q_will_inv = Q_will.conjugate(); // For a unit quaternion, inverse is the conjugate.

                    // The core rotation: P' = Q * P * Q^-1
                    currentQuaternion = Q_will.multiply(currentQuaternion).multiply(Q_will_inv);
                }
                this.log("Inverse transformation complete.");
                return currentQuaternion;
            },

            // Step 5: Map the final quaternion back to a 256-bit private key.
            quaternionToKey(q) {
                this.log("Mapping final quaternion back to 256-bit private key...");
                const buffer = new ArrayBuffer(32);
                const view = new DataView(buffer);
                
                // We extract the vector components and reconstruct the 256 bits.
                // This reverses the hashToQuaternion process.
                // Note: This is a simplified reconstruction.
                const b = BigInt(Math.round(Math.abs(q.b)));
                const c = BigInt(Math.round(Math.abs(q.c)));
                const d = BigInt(Math.round(Math.abs(q.d)));
                
                // We only have 3 components, so we'll derive the 4th.
                const a = (b + c + d) % BigInt(2**64);

                view.setBigUint64(0, a, false);
                view.setBigUint64(8, b, false);
                view.setBigUint64(16, c, false);
                view.setBigUint64(24, d, false);
                
                const keyBytes = new Uint8Array(buffer);
                return Array.from(keyBytes).map(b => b.toString(16).padStart(2, '0')).join('');
            },
            
            // Main function to run the full process
            async run(hashHex) {
                this.logElement.innerHTML = '';
                this.log("Initiating preimage derivation protocol...");
                
                if (hashHex.length !== 64 || !/^[0-9a-fA-F]+$/.test(hashHex)) {
                    this.log("ERROR: Invalid SHA-256 hash format.");
                    return "Error: Invalid hash. Must be 64 hex characters.";
                }

                const hashBytes = new Uint8Array(hashHex.match(/.{1,2}/g).map(byte => parseInt(byte, 16)));
                
                const hashQuaternion = this.hashToQuaternion(hashBytes);
                const finalQuaternion = this.applyInverseTransform(hashQuaternion);
                const privateKey = this.quaternionToKey(finalQuaternion);
                
                this.log("Derivation successful.");
                return privateKey;
            }
        };

        // ========================================================================
        // UI Event Handling
        // ========================================================================
        const generateBtn = document.getElementById('generateBtn');
        const publicHashInput = document.getElementById('publicHash');
        const outputContainer = document.getElementById('outputContainer');
        const placeholderText = document.getElementById('placeholderText');
        const loader = document.getElementById('loader');
        const privateKeyOutput = document.getElementById('privateKeyOutput');

        generateBtn.addEventListener('click', async () => {
            // Reset UI
            placeholderText.classList.add('hidden');
            privateKeyOutput.classList.add('hidden');
            loader.classList.remove('hidden');
            generateBtn.disabled = true;
            generateBtn.classList.add('opacity-50');

            const hashHex = publicHashInput.value;
            
            // Simulate processing time for effect
            await new Promise(resolve => setTimeout(resolve, 50)); 
            
            const result = await inversionEngine.run(hashHex);

            // Simulate finalization time
            await new Promise(resolve => setTimeout(resolve, 1000)); 

            loader.classList.add('hidden');
            privateKeyOutput.textContent = result;
            privateKeyOutput.classList.remove('hidden');
            generateBtn.disabled = false;
            generateBtn.classList.remove('opacity-50');
        });

    </script>
</body>
</html>
