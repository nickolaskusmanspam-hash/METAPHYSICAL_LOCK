# 48 — NFO–Ϙ Toy Descent Algorithm & Proof Sketches (Discrete Graph)
**Version:** 1.0  
**Date:** 2025-10-08  
**Series:** KUSMAN Framework — Core Verification Series v1.6

---

## 1. One‑step descent (discrete proof sketch)
Let L_G have eigenpairs (λ_j, u_j) with 0=λ_0≤λ_1≤…≤λ_{n−1}. For ε>0, K_ε = exp(−ε L_G) has spectrum e^{−ε λ_j}∈(0,1].

- **σ_ent drop:** ψ−σ_ent ψ removes all j≥k modes ⇒ strictly lowers the α‑term unless already bandlimited.
- **σ_top drop:** subtracting the harmonic component (∝u_0) strictly lowers the γ‑term unless mean zero.
- **σ_gauge drop:** normalizing global phase/magnitude minimizes the β‑term (a projection on a compact orbit).
- **K_ε drop:** δ||K_ε ψ − ψ||^2 decreases unless ψ is an eigenvector with eigenvalue 1 (i.e., harmonic).

Therefore Ψ(Q(K_ε ψ)) ≤ Ψ(ψ), strictly unless ψ is Q‑fixed.

---

## 2. Finite stabilization
Finite‑dimensionality + idempotent projections imply **eventual stationarity**: there are only finitely many bandlimited, normalized, mean‑zero states on the discrete grid within admissibility. With strict decrease off the fixed set, the iteration halts in finite T.

---

## 3. Acyclic quotient
Quotient the state space by transport (global phase and harmonic shifts). The Lyapunov Ψ descends to this quotient and defines a partial order with no positive cycles ⇒ dynamic programming or convergence proofs may be run on the quotient graph directly.

---

## 4. Practical defaults
- Choose k so that λ_k ≈ median(L_G spectrum) for balanced smoothing.
- Set Λ to the 90th percentile of ||K_ε ψ0|| norms over random ψ0 to avoid aggressive clipping.
- Typical weights: α=1, β=0.5, γ=0.5, δ=0.25.

---

**Footer:**  
— KUSMAN Framework — Core Verification Series v1.6
