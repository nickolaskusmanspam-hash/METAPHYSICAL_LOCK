# TL23 — GL(1)/GL(2) Casebook (Automorphic L-Functor Scaffold)
**Author:** Aster Lumen  
**Date:** 2025-10-09  
**Series:** KUSMAN Number Theory Tightening — Casebook

This casebook gives ready-to-use **tables** for local/global data of GL(1) (Dirichlet characters) and GL(2) (holomorphic and Maass cusp forms), aligned with your **DMR–Auto** certificates and the RH–Ϙ pipeline. Fill the templates or swap in LMFDB data.

---

## A) GL(1): Dirichlet L-functions

### A.1 Completed L-function (primitive χ mod q)
- Parity `a ∈ {0,1}` with `a=0` if χ(−1)=+1 (even), `a=1` if χ(−1)=−1 (odd).  
- Completed function
\[\Lambda(s,\chi) = \left(\frac{q}{\pi}\right)^{\frac{s+a}{2}} \Gamma\!\left(\frac{s+a}{2}\right) L(s,\chi),\quad
\Lambda(s,\chi) = \varepsilon(\chi)\, \Lambda(1-s, \overline{\chi}),\ \ |\varepsilon(\chi)|=1.\]

### A.2 Local factors
- Unramified prime `p ∤ q`: `L_p(s,χ) = (1 − χ(p) p^{−s})^{-1}` with Satake `α_p = χ(p)`.  
- Ramified prime `p ∣ q`: for primitive χ, the **Euler factor is 1** (captured by conductor), with local root number `ε_p(χ)` recorded separately.

### A.3 Tables

**GL(1) — Global metadata**

| Label | Modulus q | Primitive? | Parity a | Conductor q* | ε(χ) (global) | Notes |
|---|---:|---:|---:|---:|---|---|
| χ₁ | 5 | ✓ | 1 | 5 | (unit phase) | example row |
| χ₂ | ___ | ___ | ___ | ___ | ___ | ___ |

**GL(1) — Local factors**

| χ-label | prime p | unram? (p∤q) | χ(p) | α_p | L_p(s) | ε_p(χ) | Notes |
|---|---:|---:|---:|---:|---|---|---|
| χ₁ | 2 | ✓ | χ(2) | χ(2) | (1 − χ(2) 2^{−s})^{-1} | 1 |  |
| χ₁ | 5 | ✗ | — | — | 1 | ε_5(χ) | ramified |
| χ₂ | ___ | ___ | ___ | ___ | ___ | ___ | ___ |

---

## B) GL(2): Holomorphic newforms and Maass forms

### B.1 Completed L-function
- **Holomorphic newform** of weight k, level N, nebentypus ψ (primitive):  
\[\Lambda(s,f) = N^{\frac{s}{2}} (2\pi)^{-s} \Gamma\!\left(s + \frac{k-1}{2}\right) L(s,f),\quad
\Lambda(s,f)=\varepsilon(f)\,\Lambda(1-s, \tilde f),\ \ |\varepsilon(f)|=1.\]
- **Maass form** with spectral parameter t (weight 0):  
\[\Lambda(s,f) = N^{\frac{s}{2}} \pi^{-s}\Gamma\!\left(\frac{s+it}{2}\right)\Gamma\!\left(\frac{s-it}{2}\right) L(s,f).\]

### B.2 Local factors (finite places)
- For `p ∤ N`: unramified with Satake parameters `α_p, β_p`:
\[L_p(s,f) = (1 - α_p p^{−s})^{-1} (1 - β_p p^{−s})^{-1},\quad α_p + β_p = a_p,\ \ α_p β_p = ψ(p) p^{k-1}\ (\text{holomorphic}).\]
- For `p ∣ N`: local type (Steinberg/special, supercuspidal) determines the factor; record as **type** and the corresponding `L_p(s)` form.

### B.3 Archimedean (∞) data
- Holomorphic weight k: single Γ-factor above; Maass: two Γ_ℝ-factors (as written).

### B.4 Tables

**GL(2) — Global metadata**

| Label | Type | Level N | Weight k / t | Nebentypus ψ | Conductor N* | ε(f) | Notes |
|---|---|---:|---|---|---:|---|---|
| f₁ | holomorphic | 11 | k=2 | ψ=1 | 11 | −1 | classical example |
| f₂ | Maass | ___ | t=___ | ψ=___ | ___ | ___ | ___ |

**GL(2) — Unramified primes (p∤N)**

| f-label | p | a_p | α_p | β_p | Relation α_p+β_p=a_p | L_p(s) |
|---|---:|---:|---:|---:|---|---|
| f₁ | 2 | a₂ | root | root | ✓ | (1 − α₂ 2^{−s})^{-1}(1 − β₂ 2^{−s})^{-1} |
| f₁ | 3 | a₃ | root | root | ✓ | (1 − α₃ 3^{−s})^{-1}(1 − β₃ 3^{−s})^{-1} |
| f₂ | ___ | ___ | ___ | ___ | ___ | ___ |

**GL(2) — Ramified primes (p∣N)**

| f-label | p | Local type | Atkin–Lehner | L_p(s) (form) | Notes |
|---|---:|---|---|---|---|
| f₁ | 11 | Steinberg | w_{11}=−1 | (1 − a_{11} 11^{−s})^{-1} (typical) | fill actual factor if known |
| f₂ | ___ | ___ | ___ | ___ | ___ |

**GL(2) — Archimedean (∞) data**

| f-label | Case | Γ-factor(s) | Shift(s) | Notes |
|---|---|---|---|---|
| f₁ | holomorphic | Γ(s + (k−1)/2) | (k−1)/2 | include N^{s/2}(2π)^{−s} in Λ |
| f₂ | Maass | Γ((s+it)/2) Γ((s−it)/2) | ±it/2 | include N^{s/2}π^{−s} in Λ |

---

## C) Transfers & Stability (for DMR–Auto)

**C.1 Twists by GL(1)**  
Given Dirichlet χ, define `f ⊗ χ`: update local Satake by `α_p → χ(p) α_p`, `β_p → χ(p) β_p` at unramified `p`; update ramified data per conductor. Check that `Q`‑closed statistics (low‑lying zeros) are **stable**.

**C.2 Base change to extension K/F**  
Local factors transform via local Langlands; use the table to line up `L_v(s,π_v)` with `L_w(s,BC_K π)_w`. Stability under `Q` expected for packet‑level statistics.

**C.3 Explicit‑formula observables**  
Choose test weight `w(u)` and frequency window. Record variance/means **pre/post** `ϛ_s` and `Q`.

| Observable | Window | Pre variance | Post ϛ_s | Post Q | Notes |
|---|---|---:|---:|---:|---|
| zeros density | [0, T] |  |  |  |  |
| low‑lying statistic | small T |  |  |  |  |

**Footer:** — KUSMAN Number Theory Tightening — TL23 v1.0
