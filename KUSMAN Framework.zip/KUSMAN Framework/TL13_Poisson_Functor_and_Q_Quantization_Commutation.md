# TL13 — Poisson Functor & Q–Quantization Commutation
**Author:** Aster Lumen  
**Date:** 2025-10-09  
**Series:** KUSMAN Framework — Tightening Partials

---

## Goal
Make the Poisson functor precise and prove when Q_hbar∘Q commutes (up to error) with quantization on Poisson manifolds.

## 1. Functors
P: (M,ω) ↦ (C^∞(M),{{·,·}}_ω).  F_Pois: Pois→MMK via Hamiltonian flows + Liouville.

## 2. Commutation schema
R_hbar^Pois := Q_hbar∘Q∘F_Pois  vs  Q_hbar^quant := Q∘C_hbar∘Q_hbar.
**Thm 13.1.** On compact symplectic M with tame H, ‖R_hbar^Pois−Q_hbar^quant‖_⋄ ≤ O(hbar).

## 3. Noether invariants
Q preserves Casimirs/momentum maps after reduction; conserved quantities survive reflection.

## 4. Certificates (DMR–Pois)
- Egorov bound; Casimir list; choice of norm (trace/CB/OT).

**Footer:** — KUSMAN Tightening Partials v1.0
