# TL19 — Ω‑Logic & Compactness in \MMK
**Author:** Aster Lumen  
**Date:** 2025-10-09  
**Series:** KUSMAN Framework — Foundations Tightening

---

## Objective
Establish an internal **Ω‑logic** for \MMK that supports (i) a subobject classifier for closure‑stable monos, (ii) a complete Heyting algebra structure (under mild limits), and (iii) a **logical compactness** principle compatible with the Ϙ–ς closures and TL2 sheafification.

---

## 1. Predicate objects and Ω
Let `Pred(X)` denote measurable predicates on an MMK object `X=(|X|,d,μ,K)`.
Define the presheaf `Ω` assigning to each `X` the σ‑complete Boolean algebra of measurable predicates modulo μ‑null sets.

**Closures.** Let `j = j_ℓ ∘ j_s ∘ j_g ∘ j_a` be the Lawvere–Tierney topology from TL2. Define the **closure‑stable** subobject classifier `Ω_c ⊆ Ω` by
`Ω_c(X) := { P ∈ Ω(X) : P = j^*(P) }`, i.e., predicates invariant under all closures ϛₓ.

**Lemma 19.1 (Classifier for closure‑stable monos).** A mono `m: A ↪ X` is closure‑stable iff there exists `χ_m : X → Ω_c` with `A ≅ χ_m^{-1}(true)` and this factorization is natural in `X`.

---

## 2. Heyting structure
Pointwise operations on `Ω` induce on `Ω_c` a Heyting algebra:
- `⊤, ⊥` are the constant predicates;  `P ∧ Q`, `P ∨ Q` are intersections/unions followed by **closure‑stabilization** `j^*`.
- Implication `P ⇒ Q := j^*(¬P ∨ Q)`.
- Quantifiers along a morphism `f: X→Y` via direct/inverse images with stabilization: `∃_f P := j^*(∃_f^raw P)`, `∀_f P := j^*(∀_f^raw P)`.

**Theorem 19.2 (Complete Heyting under mild limits).** If \MMK admits products indexed by a set `I` and `Ω_c` preserves these products (true for TL2 sites with countable covers and TL1 separability), then `Ω_c` is a **complete Heyting algebra**: arbitrary joins/meets exist and distribute over implication.

**Proof sketch.** Use TL2 sheafification to compute `Ω_c` as the equalizer of the Čech diagram for `j`‑covers. Products commute with equalizers under our standing separability/tightness assumptions; closure‑stabilization is idempotent and monotone, preserving completeness.

---

## 3. Internal sequent calculus (Ϙ–ς modal rules)
Augment intuitionistic sequent rules with **modal axioms** for each ϛₓ:
- **Idempotent/monotone:** `□ₓ P ⊢ P`, `P ⊢ Q ⇒ □ₓ P ⊢ □ₓ Q`.
- **Frobenius:** `□ₓ(P ∧ Q) ≡ (□ₓ P ∧ □ₓ Q)`; right adjoints yield Beck–Chevalley for pullbacks.
- **Aggregator:** `□ := □_ℓ ∘ □_s ∘ □_g ∘ □_a` with `□□ = □`.

**Theorem 19.3 (Soundness).** All derivations in this modal sequent system are valid in `Ω_c`.

**Theorem 19.4 (Conservativity over embeddings).** For sentences in the image of the Set/Type embeddings (TL11), derivability in \MMK implies derivability in ZFC/HoTT, respectively.

---

## 4. Logical compactness
Let `Φ` be a family of `Ω_c`‑formulas indexed by `I`. Suppose every finite `J ⊂ I` has a model in \MMK. If the underlying MMK objects form a TL2 **compact site** (countable `j`‑covers with finite intersection property) and TL1 metrics are **tight**, then there exists a global model.

**Theorem 19.5 (Compactness).** Under the compact site+tightness hypotheses, the internal logic over `Ω_c` is **compact**: satisfiable finitely ⇒ satisfiable globally.

*Idea.* Construct an ultrafilter/limit along the inverse system of partial models using Prokhorov tightness in TL1; apply TL2 gluing to pass to a global section, then stabilize with `j`.

---

## 5. Certificates — DMR–Cons v2
- Classifier witness `χ_m : X→Ω_c` for each mono used  
- Modal proof trace (which ϛₓ rules applied)  
- Compactness preconditions: site compactness, TL1 tightness  
- Embedding provenance (ZFC/HoTT) for conservative fragments

**Footer:** — KUSMAN Foundations Tightening v1.0
