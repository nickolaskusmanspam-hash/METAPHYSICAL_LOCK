# TL21 — Mini Six‑Functor Formalism in \MMK (Expanded Examples & Proofs)
**Author:** Aster Lumen  
**Date:** 2025-10-09  
**Series:** KUSMAN Framework — Cohomology Tightening

---

## Objective
Establish a self‑contained six‑functor core on KUSMAN sites (TL2), prove the key adjunctions and base‑change results in the **Q‑stable** subcategory, and supply concrete worked examples (open/closed embeddings, proper maps, boundary sheaves from TL10b).

---

## 1. Setting and hypotheses
- Site: a TL2 site \(\mathcal U\) (boundary/interface or diffusion) with Lawvere–Tierney topology \(j\).  
- Coefficients: an abelian category \(\mathbf A\) of Banach/Fréchet sheaves with enough injectives; denote the Q‑stable full subcategory by \(\mathbf A^Q\subset \mathbf A\).  
- Functor \(Q: \mathbf A\to\mathbf A\) is exact on \(\mathbf A^Q\) and idempotent (TL2); closures \(\varsigma_x\) act objectwise and preserve \(\mathbf A^Q\).

**Convention.** All functors in this note are tacitly restricted to \(\mathbf A^Q\).

---

## 2. The six operations
Let \(f: \mathcal U\to\mathcal V\) be a morphism of sites.

1) **Inverse image** \(f^*: \mathbf A^Q(\mathcal V)\to\mathbf A^Q(\mathcal U)\): left exact, preserves Q‑stability; derived functor \(Lf^*\) exists when needed.

2) **Direct image** \(f_*: \mathbf A^Q(\mathcal U)\to\mathbf A^Q(\mathcal V)\): right adjoint to \(f^*\). Derived \(Rf_*\) via injective resolutions.

3) **Exceptional pushforward** \(f_!: \mathbf A^Q(\mathcal U)\to\mathbf A^Q(\mathcal V)\) (extension by zero on open embeddings; proper direct image generally). Right adjoint \(f^!\) on a triangulated subcategory \(D^+(\mathbf A^Q)\).

4) **Tensor** \(\otimes\) and **internal Hom** \(\mathcal H om\), with derived \(\otimes^L\) and \(R\mathcal H om\). On \(\mathbf A^Q\), \(Q\) is lax monoidal: natural maps \(Q(F)\otimes Q(G)\to Q(F\otimes G)\) are isos.

---

## 3. Adjunctions and projection formula
**Proposition 21.1 (Adjunctions).** There are natural bijections
\[\mathrm{Hom}(f^*G,F)\cong \mathrm{Hom}(G,f_*F),\qquad \mathrm{Hom}(f_!F,G)\cong \mathrm{Hom}(F,f^!G),\]
functorial in \(F,G\), stable under \(Q\).  
*Proof sketch.* Use the standard site‑wise Kan extension constructions and observe that Q‑stability is preserved by the unit/counit maps since \(Q\) is exact on \(\mathbf A^Q\).

**Proposition 21.2 (Projection formula).** For \(F\in D^+(\mathcal U), G\in D^+(\mathcal V)\), there is an iso
\[ Rf_*(F\otimes^L f^*G) \simeq Rf_*F \otimes^L G, \]
natural and Q‑stable.  
*Proof.* Resolve by Q‑stable K‑flat/K‑injective objects and use the monoidality of \(Q\).

---

## 4. Base change and Beck–Chevalley
Given a cartesian square of sites

\[\begin{array}{ccc}
\mathcal U' & \xrightarrow{\ g\ } & \mathcal U\\
\downarrow^{f'} && \downarrow^{f}\\
\mathcal V' & \xrightarrow{\ h\ } & \mathcal V
\end{array}\]

**Theorem 21.3 (Base change).** There are canonical isomorphisms (in derived categories)
\[ h^*\,Rf_* \simeq Rf'_*\,g^*, \qquad Rg_*\,f'^! \simeq f^!\,Rh_* ,\]
compatible with \(Q\) and closures \(\varsigma_x\).  
*Idea.* Use the usual spectral sequence argument on Čech hypercovers (TL20); Q‑stability ensures degeneration is preserved.

---

## 5. Verdier duality (Q‑stable)
Assume \(\mathcal U\) is locally compact and carries a dualizing object \(\omega_{\mathcal U}\in D^+(\mathbf A^Q)\). Define \(\mathbb D(F)=R\mathcal H om(F,\omega_{\mathcal U})\).

**Theorem 21.4 (Verdier).** There is a biduality isomorphism \(F\simeq \mathbb D\mathbb D F\) and adjunction \(Rf_!\dashv f^!\) described by \(\mathbb D\). Q‑stability: \(Q\mathbb D\cong \mathbb D Q\).

---

## 6. Worked examples
**Open embedding.** For \(j:U\hookrightarrow X\), \(j_!\) is extension by zero; projection formula and base change follow directly.  
**Proper map.** For \(p:X\to \*\), \(Rp_*\) computes cohomology; Leray spectral sequence aligns with TL20.  
**Boundary sheaves (TL10b).** With \(i:\partial\Omega\hookrightarrow \overline{\Omega}\), Green’s identity yields \(i^!\) as a boundary trace (Neumann/Dirichlet), and Mayer–Vietoris gives interface gluing.

---

## 7. Certificates — DMR–Six
- Adjunction witnesses (unit/counit) kept Q‑stable  
- Projection‑formula diagram commutes  
- Base‑change iso realized on chosen square  
- Dualizing object used and biduality check

**Footer:** — KUSMAN Cohomology Tightening v1.0
