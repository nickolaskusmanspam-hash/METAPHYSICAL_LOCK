"""
Converter: smallk_tree_mod64_H48.zip  →  dmr_m6_leaves.jsonl.gz

Goal (finite certification input):
  Produce a leaf stream where each record is
    {"root_r": int, "k": int, "weight": float, "u_start": float, "u_end": float}
  representing a Haar-weighted leaf whose mantissa U={log2 n} lies in [u_start, u_end).

What counts as a leaf here?
  A leaf is any terminal node of the small-k residue tree at depth H where the next
  accelerated odd step has v2(3n+1)=k ∈ {1,2,3}. (High-k≥4 or cascade trigger ends prefix.)

Inputs expected inside the ZIP (adapt these names if your dump differs):
  - states.json          : list of states with fields {id, mod, res, depth, root_r, mass}
  - transitions.jsonl.gz : each line: {src_id, dst_id, k, kind}
                           where kind ∈ {"k1","k2","k3","H","C","F"}
  - roots/root_<r>.json  : optional per-root summaries (not required here)

Assumptions:
  - mass at each state equals its Haar weight (sums to 1 within each root_r tree).
  - for each terminal state that emits exactly one k ∈ {1,2,3}, we map that state’s
    mantissa support to dyadic cells of length 1/64 (uniform on the cylinder mod 2^6).

Mapping to mantissa intervals:
  - For an odd state with modulus M=2^m and residue res, the cylinder is {n ≡ res (mod M)}
    with Haar mass equal to the state’s mass. Its mantissa U is uniformly distributed
    over [0,1) up to discrepancy ≤ 2^{-(m+1)}. At m≥6 we partition into 64 equal cells.
  - We therefore split the state’s mass equally across the 64 cells:
      weight_per_cell = mass / 64
    and emit 64 leaf records per (state,k): u_start=j/64, u_end=(j+1)/64.
  - This exactly matches the finite certification formulation at m=6.

Output:
  - /mnt/data/dmr_m6_leaves.jsonl.gz

If your dump uses different field names, adjust FIELD_* constants below.
"""

import os, json, gzip, zipfile
from collections import defaultdict

ZIP_PATH = r"C:\Users\Nick\Desktop\Collatz\smallk_tree_mod64_H48.zip"
OUT_PATH = r"C:\Users\Nick\Desktop\Collatz\dmr_m6_leaves.jsonl.gz"

# --- field name adapters (edit here to match your dump) ---
FIELD_ID = "id"
FIELD_MOD = "mod"
FIELD_RES = "res"
FIELD_DEPTH = "depth"
FIELD_ROOT = "root_r"
FIELD_MASS = "mass"

FIELD_SRC = "src_id"
FIELD_DST = "dst_id"
FIELD_K   = "k"
FIELD_KIND= "kind"  # 'k1','k2','k3','H','C','F'

K_SMALL = {1:"k1", 2:"k2", 3:"k3"}
TERMINAL_KINDS = {"H","C","F"}

# ----------------------------------------------------------

def read_states(z: zipfile.ZipFile):
    with z.open("states.json") as fh:
        data = json.load(fh)
    states = { s[FIELD_ID]: s for s in data }
    return states


def iter_transitions(z: zipfile.ZipFile):
    with z.open("transitions.jsonl.gz") as fh_gz:
        with gzip.open(fh_gz) as gh:
            for line in gh:
                yield json.loads(line)


def build_terminal_smallk(states, transitions):
    """Return mapping state_id -> list of emitted small-k labels at terminal (before H/C/F)."""
    # Build adjacency and out-kinds per state
    outk = defaultdict(set)
    outdeg = defaultdict(int)
    for tr in transitions:
        src = tr[FIELD_SRC]; kind = tr[FIELD_KIND]
        outdeg[src] += 1
        if kind in ("k1","k2","k3"):
            outk[src].add(kind)
        if kind in TERMINAL_KINDS:
            outk[src].add(kind)
    # A terminal small-k leaf is a state that has exactly one small-k outgoing kind
    # AND also has a terminal trigger among its outgoing kinds; we then record that 'k'.
    leaves = {}  # state_id -> k∈{1,2,3}
    for sid, kinds in outk.items():
        small = [k for k in kinds if k in ("k1","k2","k3")]
        has_term = any((k in TERMINAL_KINDS) for k in kinds)
        if len(small)==1 and has_term:
            klabel = small[0]
            k = 1 if klabel=="k1" else 2 if klabel=="k2" else 3
            leaves[sid] = k
    return leaves


def write_dmr_leaves(states, leaves):
    with gzip.open(OUT_PATH, "wt", encoding="utf-8") as gh:
        for sid, k in leaves.items():
            st = states[sid]
            mass = float(st.get(FIELD_MASS, 0.0))
            root_r = int(st.get(FIELD_ROOT))
            # Split mass uniformly into 64 dyadic cells at m=6
            w = mass / 64.0
            for j in range(64):
                rec = {
                    "root_r": root_r,
                    "k": k,
                    "weight": w,
                    "u_start": j/64.0,
                    "u_end": (j+1)/64.0
                }
                gh.write(json.dumps(rec) + "\n")


if __name__ == "__main__":
    assert os.path.exists(ZIP_PATH), f"Missing {ZIP_PATH}"
    with zipfile.ZipFile(ZIP_PATH) as z:
        states = read_states(z)
        transitions = list(iter_transitions(z))
    leaves = build_terminal_smallk(states, transitions)
    write_dmr_leaves(states, leaves)
    print(f"Wrote {OUT_PATH} with {len(leaves)*64} rows (64 dyadic cells per leaf).")
