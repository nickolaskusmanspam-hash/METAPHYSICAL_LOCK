# checker_dmr_m6.py — finite certification of DMR at m=6
# Verifies: for each odd r mod 64 and k∈{1,2,3},
# sup_{dyadic I of length 1/64} | P(U∈I | r,k) - |I| | ≤ 1/128,
# where U={log2 N} and probabilities are Haar weights on the depth-H residue tree.

import math, json, gzip
from collections import defaultdict

M = 64  # 2^6
DYADIC_CELLS = [ (j/64.0, (j+1)/64.0) for j in range(64) ]

def load_tree_leaves(path_jsonl_gz):
    """Each line: {"root_r":int, "k":int, "weight":float, "u_start":float, "u_end":float}
       meaning: leaf contributes mantissa interval [u_start,u_end) with Haar weight.
       Produce dict[(r,k)] -> list of (weight, u_start, u_end)."""
    buckets = defaultdict(list)
    with gzip.open(path_jsonl_gz, "rt", encoding="utf-8") as fh:
        for line in fh:
            rec = json.loads(line)
            r = int(rec["root_r"]); k = int(rec["k"])
            w = float(rec["weight"])
            u0 = float(rec["u_start"]); u1 = float(rec["u_end"])
            buckets[(r,k)].append((w,u0,u1))
    return buckets

def interval_mass(leaves, a, b):
    """Mass of U in [a,b) from union of weighted intervals in leaves."""
    s = 0.0
    for w,u0,u1 in leaves:
        # overlap length
        L = max(0.0, min(b,u1) - max(a,u0))
        # assume leaves partition measure under Haar (precomputed); add proportional weight
        if u1 > u0 and L > 0:
            s += w * (L / (u1 - u0))
    return s

def certify_dmr(buckets, tol=1/128):
    worst = {}
    ok = True
    for r in range(1,64,2):
        for k in (1,2,3):
            leaves = buckets.get((r,k), [])
            if not leaves:
                continue
            max_dev = 0.0
            for a,b in DYADIC_CELLS:
                p = interval_mass(leaves, a, b)
                dev = abs(p - (b-a))
                if dev > max_dev:
                    max_dev = dev
            worst[(r,k)] = max_dev
            if max_dev > tol + 1e-12:
                ok = False
    return ok, worst

if __name__ == "__main__":
    # Expect a precomputed leaf file from your tree engine:
    # Each leaf maps to a mantissa interval [u0,u1) with a Haar weight.
    buckets = load_tree_leaves("/mnt/data/dmr_m6_leaves.jsonl.gz")
    ok, worst = certify_dmr(buckets)
    print("DMR(m=6) certified:", ok, "max deviation =", max(worst.values()) if worst else None)
    # write a JSON report
    with open("/mnt/data/dmr_m6_report.json","w") as f:
        json.dump({"ok": ok, "worst_dev": max(worst.values()) if worst else None, "per_rk": worst}, f, indent=2)
