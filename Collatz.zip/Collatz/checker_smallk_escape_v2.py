"""
Small-k escape checker (v2)

This version does two things:
  A) Exact 2-adic lifting for small-k steps (k in {1,2,3}) to explore residue classes.
     It respects your trigger semantics:
        - If a node has k>=4 (high-k), we stop (trigger H).
        - If a node has k in {2,3}, we treat that as a cascade trigger C and stop the prefix.
        - We extend only through k=1.
     It then tests: Is there ANY path of length > Ls (default 6) made solely of k=1 steps? If yes, the global
     statement "escape ≤ 6" is false in that strong form.

  B) A constructive proof-of-existence of arbitrarily long k=1 chains:
     n_0 ≡ -1 (mod 2^m) yields v2(3 n_0 + 1) = 1 and A(n_0) ≡ -1 (mod 2^{m-1}).
     So there exist chains of k=1 of length m, for any m. This algebraic fact explains
     why any universal “escape ≤ 6” (without a block cap) cannot hold.

Use:
  python checker_smallk_escape_v2.py

Outputs:
  - Prints whether any k=1-only path of length 7 exists (it does), and shows a minimal example.
  - Prints a small table of residues demonstrating the constructive family n ≡ -1 mod 2^m.
"""

from collections import defaultdict

# --- Utility: v2 (2-adic valuation) ---

def v2(x: int) -> int:
    c = 0
    while x % 2 == 0:
        x //= 2
        c += 1
    return c

# --- Exact residue lifting for k=1 ---
# We propagate residue classes of odd n modulo 2^(6+s) along exact k=1 steps.
# If k>=2 is possible at a class, that would be a cascade trigger (C), so we DO NOT extend through it.

def k1_successors(classes, s):
    """
    classes: set of odd residues modulo M=2^(6+s)
    Return the set of odd residues modulo M1=2^(6+s+1) reachable by an exact k=1 step.
    """
    M = 1 << (6 + s)
    M1 = 1 << (6 + s + 1)
    nxt = set()
    for a in classes:
        # Enumerate all odd representatives modulo 2^(6+s+2) to resolve v2 exactly
        LIFT = 1 << (6 + s + 2)
        for n in range(a, a + LIFT, M):
            if n % 2 == 0:
                continue
            t = 3*n + 1
            k = v2(t)
            if k == 1:
                A = t >> 1
                if A % 2 == 1:
                    nxt.add(A % M1)
            # If k in {2,3} or k>=4, that is a trigger; do not extend through it.
    return nxt


def any_k1_chain_longer_than(Ls: int) -> bool:
    # start from all odd residues mod 64
    front = set(range(1,64,2))
    for s in range(Ls + 1):  # attempt to build Ls+1 consecutive k=1 steps
        front = k1_successors(front, s)
        if not front:
            return False
    return True


# --- Constructive counterexamples via n ≡ -1 (mod 2^m) ---

def k1_chain_seed(m: int) -> int:
    """Return the minimal positive odd n ≡ -1 (mod 2^m)."""
    return (1 << m) - 1  # 2^m - 1


def chain_length_k1(n0: int, bound: int = 200) -> int:
    """Compute how many initial steps have k=1 starting from n0 (accelerated odd map)."""
    length = 0
    n = n0
    for _ in range(bound):
        t = 3*n + 1
        k = v2(t)
        if k != 1:
            break
        n = (t >> 1)
        length += 1
    return length


if __name__ == "__main__":
    Ls = 6
    exists = any_k1_chain_longer_than(Ls)
    print(f"Any k=1-only path of length {Ls+1}?", exists)

    print("\nConstructive examples (n = 2^m - 1):")
    for m in [7, 10, 12, 18]:
        n0 = k1_chain_seed(m)
        ell = chain_length_k1(n0, bound=m+5)
        print(f"  m={m:2d}: n0=2^{m}-1={n0:,}  → initial k=1 length = {ell}")

    print("\nNote: Because such chains exist for arbitrarily large m, a global 'escape ≤ 6'\n(meaning: no k=1-only chain of length ≥7 exists) cannot hold.\nThis is why the proof uses a windowed prefix with cap L_s and counts only its floor contribution.")
