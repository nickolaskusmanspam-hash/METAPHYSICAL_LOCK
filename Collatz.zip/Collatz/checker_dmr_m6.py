"""
Finite certification of Dyadic Mantissa Regularity at m = 6.

Input: dmr_m6_leaves.jsonl.gz from the builder (one line per dyadic cell)
Record fields: {root_r, k, weight, u_start, u_end}

Certification statement:
  For each odd root_r and each k ∈ {1,2,3},
    sup_{dyadic cell I of length 1/64} | P(U∈I | r,k) − |I| | ≤ 1/128.
Writes dmr_m6_report.json and prints the worst deviation.
"""

import json, gzip
from collections import defaultdict

IN_PATH = "dmr_m6_leaves.jsonl.gz"
OUT_PATH = "dmr_m6_report.json"
CELLS = [(j/64.0, (j+1)/64.0) for j in range(64)]

def load_buckets():
    buckets = defaultdict(list)
    with gzip.open(IN_PATH, "rt", encoding="utf-8") as fh:
        for line in fh:
            rec = json.loads(line)
            buckets[(int(rec["root_r"]), int(rec["k"]))].append(
                (float(rec["weight"]), float(rec["u_start"]), float(rec["u_end"]))
            )
    return buckets

def interval_mass(leaves, a, b):
    s = 0.0
    for w,u0,u1 in leaves:
        if u0 >= b or u1 <= a:
            continue
        L = min(b,u1) - max(a,u0)
        if L > 0:
            s += w * (L / (u1 - u0))
    return s

def certify(tol=1/128):
    buckets = load_buckets()
    worst = {}
    ok = True
    for r in range(1,64,2):
        for k in (1,2,3):
            leaves = buckets.get((r,k), [])
            if not leaves:  # e.g. immediate high-k roots
                continue
            max_dev = 0.0
            for a,b in CELLS:
                p = interval_mass(leaves, a, b)
                dev = abs(p - (b-a))  # (b-a) == 1/64
                if dev > max_dev:
                    max_dev = dev
            worst[(r,k)] = max_dev
            if max_dev > tol + 1e-12:
                ok = False
    report = {
        "ok": ok,
        "worst_dev": max(worst.values()) if worst else None,
        "per_rk": {f"{r}:{k}": d for (r,k), d in worst.items()}
    }
    with open(OUT_PATH, "w") as f:
        json.dump(report, f, indent=2)
    print("DMR(m=6) certified:", ok, "max deviation =", report["worst_dev"])

if __name__ == "__main__":
    certify()
