"""
Build dmr_m6_leaves.jsonl.gz from root residues (finite DMR certification input).

For each odd residue r mod 64, compute k0 = v2(3*r + 1). If k0 ∈ {1,2,3}, we create
64 dyadic mantissa cells (length 1/64) with equal Haar weight 1/64 and tag them with (root_r=r, k=k0).
For residues with immediate high-k (k0 ≥ 4; e.g., r ∈ {5,21,37,53}), we skip (no small-k leaf).

This matches the m=6 dyadic partition in your lemma: under Haar on mod-64 cylinders,
the mantissa U is uniform on dyadic cells at resolution 2^6, with discrepancy ≤ 1/128.
"""

import gzip, json

OUT = "dmr_m6_leaves.jsonl.gz"

def v2(x: int) -> int:
    c = 0
    while x % 2 == 0:
        x //= 2
        c += 1
    return c

def main():
    total = 0
    with gzip.open(OUT, "wt", encoding="utf-8") as gh:
        for r in range(1, 64, 2):  # odd residues
            k0 = v2(3*r + 1)       # first-step valuation determined by r (for k ≤ 6)
            if k0 in (1, 2, 3):
                w = 1.0 / 64.0     # equal weight per dyadic cell at m=6
                for j in range(64):
                    gh.write(json.dumps({
                        "root_r": r,
                        "k": k0,
                        "weight": w,
                        "u_start": j/64.0,
                        "u_end": (j+1)/64.0
                    }) + "\n")
                total += 64
    print(f"Wrote {total} rows to {OUT}")

if __name__ == "__main__":
    main()
