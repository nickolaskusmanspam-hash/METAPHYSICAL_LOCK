"""
OST Chain — Collatz Braid‑Sieve (Reproducible Notebook-as-Script)

This script mirrors a Jupyter notebook and reproduces the contradiction chain:
  1) Load macro‑block dataset (JSONL.GZ from small‑k congruence sampling)
  2) Verify bounded increments (continuous + raw)
  3) Compute empirical log‑MGF ψ(t) and Chernoff rates I(x)
  4) Plug symbolic cf48 bounds (ε = 1/128, L_s = 6 → c_f^* = 3/64)
  5) Present OST inequality chain and tail bounds; save figures + CSVs

Inputs (adjust paths under CONFIG):
  - collatz_smallk_congruence_tree_sample.jsonl.gz  (640k macro‑blocks)
  - (optional) cf48_symbolic_per_residue.csv and cf48_symbolic_summary.json

Outputs (written next to the script unless OUTPUT_DIR is changed):
  - stats/*.json : summary numbers
  - tables/*.csv : per‑residue and MGF tables
  - plots/*.png  : histograms, ψ(t), Chernoff tails

Run:
  python ost_chain_collatz.py

Note: matplotlib only; no seaborn. Each plot uses a single figure (no subplots) per instruction.
"""

import os
import json
import math
import gzip
from typing import Dict, Any, Iterable, Tuple, List

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# ---------------------------
# CONFIG
# ---------------------------
DATA_DIR = r"C:\Users\Nick\Desktop\Collatz"
INPUT_JSONL_GZ = os.path.join(DATA_DIR, "collatz_smallk_congruence_tree_sample.jsonl.gz")
CF48_CSV_OPT = os.path.join(DATA_DIR, "cf48_symbolic_per_residue.csv")
CF48_SUMMARY_OPT = os.path.join(DATA_DIR, "cf48_symbolic_summary.json")
OUTPUT_DIR = os.path.join(DATA_DIR, "ost_outputs")

os.makedirs(OUTPUT_DIR, exist_ok=True)
os.makedirs(os.path.join(OUTPUT_DIR, "plots"), exist_ok=True)
os.makedirs(os.path.join(OUTPUT_DIR, "tables"), exist_ok=True)
os.makedirs(os.path.join(OUTPUT_DIR, "stats"), exist_ok=True)

# Keys present in the JSONL.GZ dataset (tune here if your field names differ)
KEYS = {
    "root_r": "root_r",                 # residue mod 64 at entry
    "steps_small": "steps_small",       # small‑k prefix length in steps
    "trigger": "trigger",               # one of {"H","C","F"}
    "cum_dS": "cum_dS",                 # RAW macro ΔS (incl. floor)
    "floor_diff": "floor_diff",         # floor contribution over macro prefix (bits)
    "Sdelta0": "Sdelta0",               # optional: starting S_δ
    "Sdelta_end": "Sdelta_end"          # optional: ending S_δ
}

# Symbolic cf48 constants from the lemma
EPSILON_PER_STEP = 1.0 / 128.0  # bits
L_S_CAP = 6                     # steps
CF48_STAR = 3.0 / 64.0          # = L_S_CAP * EPSILON_PER_STEP

# Drift constants used in OST section (adjust if you refine)
ETA_BITS = 1.8                  # uniform negative drift target (bits per macro)
BAND_B_STAR = 70.5              # capture band threshold in S_δ units

# ---------------------------
# IO helpers
# ---------------------------

def iter_jsonl_gz(path: str) -> Iterable[Dict[str, Any]]:
    with gzip.open(path, "rt", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            try:
                yield json.loads(line)
            except json.JSONDecodeError:
                continue

# ---------------------------
# 1) LOAD DATA
# ---------------------------

def load_macroblocks(path: str) -> pd.DataFrame:
    rows = []
    for rec in iter_jsonl_gz(path):
        try:
            r = int(rec.get(KEYS["root_r"]))
            steps_small = int(rec.get(KEYS["steps_small"]))
            trigger = str(rec.get(KEYS["trigger"]))
            cum_dS = float(rec.get(KEYS["cum_dS"]))
            floor_diff = float(rec.get(KEYS["floor_diff"]))
        except Exception:
            # Skip malformed rows
            continue
        cont_dS = cum_dS - floor_diff
        rows.append({
            "root_r": r,
            "steps_small": steps_small,
            "trigger": trigger,
            "cum_dS": cum_dS,
            "floor_diff": floor_diff,
            "cont_dS": cont_dS
        })
    df = pd.DataFrame(rows)
    return df

print("Loading macro‑block dataset…")
mb = load_macroblocks(INPUT_JSONL_GZ)
print(f"Loaded {len(mb):,} macro‑blocks.")

# ---------------------------
# 2) BOUNDED INCREMENTS CHECKS
# ---------------------------

def summarize_bounded_increments(df: pd.DataFrame) -> Dict[str, Any]:
    stats = {
        "n": int(len(df)),
        "steps_small_max": float(df["steps_small"].max()) if len(df) else None,
        "cont_dS_min": float(df["cont_dS"].min()) if len(df) else None,
        "cont_dS_max": float(df["cont_dS"].max()) if len(df) else None,
        "cum_dS_min": float(df["cum_dS"].min()) if len(df) else None,
        "cum_dS_max": float(df["cum_dS"].max()) if len(df) else None,
    }
    return stats

bounded_stats = summarize_bounded_increments(mb)
with open(os.path.join(OUTPUT_DIR, "stats", "bounded_increments.json"), "w") as f:
    json.dump(bounded_stats, f, indent=2)
print("Bounded increments summary saved.")

# Histograms
plt.figure()
mb["cont_dS"].dropna().hist(bins=120)
plt.title("Continuous ΔS per macro‑block (histogram)")
plt.xlabel("cont_dS (bits)")
plt.ylabel("count")
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, "plots", "hist_cont_dS.png"))
plt.close()

plt.figure()
mb["cum_dS"].dropna().hist(bins=120)
plt.title("Raw ΔS per macro‑block (histogram)")
plt.xlabel("ΔS (bits)")
plt.ylabel("count")
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, "plots", "hist_cum_dS.png"))
plt.close()

# ---------------------------
# 3) EMPIRICAL LOG‑MGF AND CHERNOFF RATES
# ---------------------------

def log_mgf(samples: np.ndarray, t: float) -> float:
    # Stable computation: subtract max to avoid overflow
    a = t * samples
    a_max = np.max(a)
    return float(a_max + np.log(np.mean(np.exp(a - a_max))))

def chernoff_rate(samples: np.ndarray, x: float, t_grid: np.ndarray) -> Tuple[float, float]:
    # Returns (I(x), t*) where I(x)=sup_t (t x − ψ(t))
    psi_vals = np.array([log_mgf(samples, t) for t in t_grid])
    vals = t_grid * x - psi_vals
    idx = int(np.argmax(vals))
    return float(vals[idx]), float(t_grid[idx])

# compute on raw macro ΔS
delta_samples = mb["cum_dS"].to_numpy(dtype=float)

# t grid for Chernoff
T_MAX = 2.0
N_T = 401
T_GRID = np.linspace(-T_MAX, T_MAX, N_T)

chernoff_points = []
for x in [0.3, 0.6, 0.9, 1.2, 1.5, 1.8]:
    I_x, t_star = chernoff_rate(delta_samples, x, T_GRID)
    chernoff_points.append({"x_bits": x, "I_x": I_x, "t_star": t_star})

chernoff_df = pd.DataFrame(chernoff_points)
chernoff_df.to_csv(os.path.join(OUTPUT_DIR, "tables", "chernoff_rates.csv"), index=False)

# ψ(t) table for plotting
psi_rows = []
for t in T_GRID:
    psi_rows.append({"t": t, "psi": log_mgf(delta_samples, t)})
psi_df = pd.DataFrame(psi_rows)
psi_df.to_csv(os.path.join(OUTPUT_DIR, "tables", "log_mgf_table.csv"), index=False)

# ψ(t) plot
plt.figure()
plt.plot(psi_df["t"], psi_df["psi"], lw=2)
plt.title("Empirical log‑MGF ψ(t) of macro ΔS")
plt.xlabel("t")
plt.ylabel("ψ(t)")
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, "plots", "psi_macro.png"))
plt.close()

# Chernoff rate plot (I(x) vs x)
plt.figure()
plt.plot(chernoff_df["x_bits"], chernoff_df["I_x"], marker="o", lw=2)
plt.title("Chernoff rate I(x) for macro ΔS")
plt.xlabel("x (bits)")
plt.ylabel("I(x)")
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, "plots", "chernoff_rate_curve.png"))
plt.close()

# Tail examples table: P(average ≥ x) ≤ exp(−m I(x)) for selected m
m_values = [50, 100, 200]
rows = []
for _, row in chernoff_df.iterrows():
    x = float(row["x_bits"])
    I_x = float(row["I_x"])
    for m in m_values:
        tail = math.exp(-m * I_x)
        rows.append({"x_bits": x, "m_blocks": m, "tail_bound": tail})

pd.DataFrame(rows).to_csv(os.path.join(OUTPUT_DIR, "tables", "chernoff_tail_examples.csv"), index=False)

# ---------------------------
# 4) CF48 SYMBOLIC CONSTANTS
# ---------------------------
cf48_summary = {
    "epsilon_per_step_bits": EPSILON_PER_STEP,
    "L_s_cap_steps": L_S_CAP,
    "cf_star_bits": CF48_STAR
}
with open(os.path.join(OUTPUT_DIR, "stats", "cf48_summary.json"), "w") as f:
    json.dump(cf48_summary, f, indent=2)

# If a per‑residue CSV exists, copy or re‑emit a compact version
if os.path.exists(CF48_CSV_OPT):
    try:
        df_cf = pd.read_csv(CF48_CSV_OPT)
        df_cf.to_csv(os.path.join(OUTPUT_DIR, "tables", "cf48_symbolic_per_residue.csv"), index=False)
    except Exception:
        pass

# ---------------------------
# 5) OST INEQUALITY CHAIN — DIAGNOSTIC NUMBERS
# ---------------------------
# Expected hitting time upper bound (illustrative): E[σ_b] ≤ (Sδ0 − b*) / η
# We dump a simple function users can call for their chosen Sδ0

def expected_hitting_time_upper_bound(Sdelta0: float, b_star: float = BAND_B_STAR, eta_bits: float = ETA_BITS) -> float:
    return max(0.0, (Sdelta0 - b_star) / eta_bits)

examples = {
    "eta_bits": ETA_BITS,
    "b_star": BAND_B_STAR,
    "examples": {
        "Sdelta0=120": expected_hitting_time_upper_bound(120.0),
        "Sdelta0=200": expected_hitting_time_upper_bound(200.0)
    }
}
with open(os.path.join(OUTPUT_DIR, "stats", "ost_examples.json"), "w") as f:
    json.dump(examples, f, indent=2)

print("\n=== OST Chain Summary ===")
print(f"Bounded increments: steps_small_max={bounded_stats['steps_small_max']}, cont_dS in [{bounded_stats['cont_dS_min']}, {bounded_stats['cont_dS_max']}], "
      f"ΔS in [{bounded_stats['cum_dS_min']}, {bounded_stats['cum_dS_max']}]")
print(f"cf48: ε={EPSILON_PER_STEP} bits per step, L_s={L_S_CAP} → c_f^*={CF48_STAR} bits")
print("Chernoff keypoints (x bits, I(x)):")
for _, r in chernoff_df.iterrows():
    print(f"  x={r['x_bits']:.1f}, I={r['I_x']:.4f}")
print("Outputs under:", OUTPUT_DIR)
